import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
import plotly.express as px
from utils.data_handler import DataHandler
from utils.visualization import create_summary_metrics
import os

# Configure page
st.set_page_config(
    page_title="CrowdGuard AI Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize data handler
@st.cache_resource
def get_data_handler():
    return DataHandler()

data_handler = get_data_handler()

# Main dashboard header
st.title("🛡️ CrowdGuard AI Dashboard")
st.markdown("**Real-time Crowd Detection & Safety Management System**")

# Sidebar navigation info
with st.sidebar:
    st.header("📊 Navigation")
    st.markdown("""
    - **Live Detection**: Real-time crowd monitoring
    - **Analytics**: Historical data analysis
    - **Alert Management**: Configure and view alerts
    - **Settings**: System configuration
    """)
    
    st.header("🔧 System Status")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Status", "🟢 Active")
    with col2:
        st.metric("Accuracy", "76.5%")

# Main dashboard overview
col1, col2, col3, col4 = st.columns(4)

# Load recent data for metrics
recent_data = data_handler.get_recent_data(hours=24)

with col1:
    current_count = recent_data['crowd_count'].iloc[-1] if len(recent_data) > 0 else 0
    st.metric("Current Crowd Count", current_count, delta=None)

with col2:
    avg_count = recent_data['crowd_count'].mean() if len(recent_data) > 0 else 0
    st.metric("24h Average", f"{avg_count:.1f}", delta=None)

with col3:
    peak_count = recent_data['crowd_count'].max() if len(recent_data) > 0 else 0
    st.metric("24h Peak", peak_count, delta=None)

with col4:
    total_alerts = len(recent_data[recent_data['alert_triggered']]) if len(recent_data) > 0 else 0
    st.metric("Active Alerts", total_alerts, delta=None)

st.divider()

# Recent activity overview
st.header("📈 Recent Activity Overview")

if len(recent_data) > 0:
    # Create time series chart
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=recent_data['timestamp'],
        y=recent_data['crowd_count'],
        mode='lines+markers',
        name='Crowd Count',
        line=dict(color='#1f77b4', width=2),
        marker=dict(size=4)
    ))
    
    # Add alert threshold line
    threshold = 50  # Default threshold
    fig.add_hline(
        y=threshold,
        line_dash="dash",
        line_color="red",
        annotation_text="Alert Threshold"
    )
    
    # Highlight alert periods
    alert_data = recent_data[recent_data['alert_triggered']]
    if len(alert_data) > 0:
        fig.add_trace(go.Scatter(
            x=alert_data['timestamp'],
            y=alert_data['crowd_count'],
            mode='markers',
            name='Alerts',
            marker=dict(color='red', size=8, symbol='triangle-up')
        ))
    
    fig.update_layout(
        title="Crowd Count Trends (Last 24 Hours)",
        xaxis_title="Time",
        yaxis_title="Crowd Count",
        height=400,
        showlegend=True
    )
    
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info("No recent data available. Start live detection to begin monitoring.")

# Recent alerts section
st.header("🚨 Recent Alerts")

alerts_data = data_handler.get_recent_alerts(limit=5)
if len(alerts_data) > 0:
    for _, alert in alerts_data.iterrows():
        with st.container():
            col1, col2, col3 = st.columns([1, 2, 1])
            with col1:
                st.write(f"**{alert['timestamp'].strftime('%H:%M:%S')}**")
            with col2:
                st.write(f"High crowd density detected: {alert['crowd_count']} people")
            with col3:
                if alert['confidence'] > 0.8:
                    st.write("🔴 High Confidence")
                elif alert['confidence'] > 0.6:
                    st.write("🟡 Medium Confidence")
                else:
                    st.write("🟢 Low Confidence")
            st.divider()
else:
    st.info("No recent alerts. System is monitoring normally.")

# System performance metrics
st.header("⚡ System Performance")

col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Detection Accuracy", "76.5%", delta="2.3%")

with col2:
    st.metric("Alert Precision", "64.5%", delta="-1.2%")

with col3:
    st.metric("Processing Speed", "24 FPS", delta="1 FPS")

# Quick actions
st.header("🚀 Quick Actions")

col1, col2, col3, col4 = st.columns(4)

with col1:
    if st.button("🎥 Start Live Detection", use_container_width=True):
        st.switch_page("pages/1_Live_Detection.py")

with col2:
    if st.button("📊 View Analytics", use_container_width=True):
        st.switch_page("pages/2_Analytics.py")

with col3:
    if st.button("🚨 Manage Alerts", use_container_width=True):
        st.switch_page("pages/3_Alert_Management.py")

with col4:
    if st.button("⚙️ System Settings", use_container_width=True):
        st.switch_page("pages/4_Settings.py")

# Footer
st.divider()
st.markdown("""
<div style='text-align: center; color: #666;'>
    <p>CrowdGuard AI v1.0 | Real-time Crowd Detection System | Powered by YOLOv8</p>
</div>
""", unsafe_allow_html=True)
