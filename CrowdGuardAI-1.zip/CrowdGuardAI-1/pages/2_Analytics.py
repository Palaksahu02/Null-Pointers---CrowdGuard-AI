import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from utils.data_handler import DataHandler
from utils.visualization import create_summary_metrics, create_correlation_analysis

st.set_page_config(
    page_title="Analytics - CrowdGuard AI",
    page_icon="📊",
    layout="wide"
)

st.title("📊 Crowd Analytics Dashboard")
st.markdown("**Comprehensive analysis of crowd patterns and system performance**")

# Initialize data handler
@st.cache_resource
def get_data_handler():
    return DataHandler()

data_handler = get_data_handler()

# Sidebar filters
with st.sidebar:
    st.header("🔍 Analytics Filters")
    
    # Time range selection
    time_range = st.selectbox(
        "Time Range",
        ["Last Hour", "Last 6 Hours", "Last 24 Hours", "Last Week", "Last Month", "Custom Range"]
    )
    
    if time_range == "Custom Range":
        start_date = st.date_input("Start Date", datetime.now().date() - timedelta(days=7))
        end_date = st.date_input("End Date", datetime.now().date())
        start_time = st.time_input("Start Time", datetime.now().time())
        end_time = st.time_input("End Time", datetime.now().time())
    
    # Analysis options
    st.subheader("Analysis Options")
    show_trends = st.checkbox("Show Trend Analysis", value=True)
    show_patterns = st.checkbox("Show Pattern Recognition", value=True)
    show_alerts = st.checkbox("Include Alert Analysis", value=True)
    show_performance = st.checkbox("Show Performance Metrics", value=True)
    
    # Venue type for context
    venue_type = st.selectbox(
        "Venue Type",
        ["General", "Temple", "Mall", "Event/Concert", "Stadium", "Transit Hub"]
    )

# Get data based on time range
if time_range == "Last Hour":
    data = data_handler.get_recent_data(hours=1)
elif time_range == "Last 6 Hours":
    data = data_handler.get_recent_data(hours=6)
elif time_range == "Last 24 Hours":
    data = data_handler.get_recent_data(hours=24)
elif time_range == "Last Week":
    data = data_handler.get_recent_data(hours=168)
elif time_range == "Last Month":
    data = data_handler.get_recent_data(hours=720)
else:  # Custom Range
    start_datetime = datetime.combine(start_date, start_time)
    end_datetime = datetime.combine(end_date, end_time)
    data = data_handler.get_data_range(start_datetime, end_datetime)

# Overview metrics
st.header("📈 Overview Metrics")

if len(data) > 0:
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        total_detections = len(data)
        st.metric("Total Detections", f"{total_detections:,}")
    
    with col2:
        avg_crowd = data['crowd_count'].mean()
        st.metric("Average Crowd", f"{avg_crowd:.1f}")
    
    with col3:
        peak_crowd = data['crowd_count'].max()
        peak_time = data.loc[data['crowd_count'].idxmax(), 'timestamp']
        st.metric("Peak Crowd", peak_crowd, 
                 delta=f"at {peak_time.strftime('%H:%M')}")
    
    with col4:
        total_alerts = data['alert_triggered'].sum()
        alert_rate = (total_alerts / len(data)) * 100 if len(data) > 0 else 0
        st.metric("Total Alerts", total_alerts, 
                 delta=f"{alert_rate:.1f}% rate")
    
    with col5:
        avg_confidence = data['confidence'].mean()
        st.metric("Avg Confidence", f"{avg_confidence:.2f}")

    st.divider()

    # Main time series analysis
    st.header("📊 Crowd Trends Analysis")
    
    # Create comprehensive time series chart
    fig = go.Figure()
    
    # Main crowd count line
    fig.add_trace(go.Scatter(
        x=data['timestamp'],
        y=data['crowd_count'],
        mode='lines+markers',
        name='Crowd Count',
        line=dict(color='#1f77b4', width=2),
        marker=dict(size=4),
        hovertemplate='<b>Time:</b> %{x}<br><b>Count:</b> %{y}<br><extra></extra>'
    ))
    
    # Add moving average if enough data points
    if len(data) > 10:
        window_size = min(10, len(data) // 5)
        moving_avg = data['crowd_count'].rolling(window=window_size).mean()
        fig.add_trace(go.Scatter(
            x=data['timestamp'],
            y=moving_avg,
            mode='lines',
            name=f'Moving Average ({window_size})',
            line=dict(color='orange', width=2, dash='dash')
        ))
    
    # Add alert markers
    if show_alerts:
        alert_data = data[data['alert_triggered']]
        if len(alert_data) > 0:
            fig.add_trace(go.Scatter(
                x=alert_data['timestamp'],
                y=alert_data['crowd_count'],
                mode='markers',
                name='Alerts',
                marker=dict(color='red', size=10, symbol='triangle-up'),
                hovertemplate='<b>ALERT!</b><br><b>Time:</b> %{x}<br><b>Count:</b> %{y}<br><extra></extra>'
            ))
    
    # Add threshold line (dynamic based on venue type)
    thresholds = {
        "General": 50,
        "Temple": 40,
        "Mall": 60,
        "Event/Concert": 80,
        "Stadium": 100,
        "Transit Hub": 45
    }
    threshold = thresholds.get(venue_type, 50)
    
    fig.add_hline(
        y=threshold,
        line_dash="dash",
        line_color="red",
        annotation_text=f"{venue_type} Alert Threshold ({threshold})"
    )
    
    fig.update_layout(
        title=f"Crowd Count Analysis - {time_range}",
        xaxis_title="Time",
        yaxis_title="Crowd Count",
        height=500,
        showlegend=True,
        hovermode='x unified'
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Pattern analysis
    if show_patterns:
        st.header("🔍 Pattern Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Hourly patterns
            if len(data) > 24:  # Enough data for hourly analysis
                data['hour'] = data['timestamp'].dt.hour
                hourly_avg = data.groupby('hour')['crowd_count'].agg(['mean', 'max', 'count']).reset_index()
                
                fig_hourly = go.Figure()
                
                fig_hourly.add_trace(go.Bar(
                    x=hourly_avg['hour'],
                    y=hourly_avg['mean'],
                    name='Average Count',
                    marker_color='lightblue',
                    opacity=0.7
                ))
                
                fig_hourly.add_trace(go.Scatter(
                    x=hourly_avg['hour'],
                    y=hourly_avg['max'],
                    mode='lines+markers',
                    name='Peak Count',
                    line=dict(color='red', width=2)
                ))
                
                fig_hourly.update_layout(
                    title="Crowd Patterns by Hour",
                    xaxis_title="Hour of Day",
                    yaxis_title="Crowd Count",
                    height=400
                )
                
                st.plotly_chart(fig_hourly, use_container_width=True)
        
        with col2:
            # Distribution analysis
            fig_dist = go.Figure()
            
            fig_dist.add_trace(go.Histogram(
                x=data['crowd_count'],
                nbinsx=20,
                name='Crowd Count Distribution',
                marker_color='skyblue',
                opacity=0.7
            ))
            
            fig_dist.add_vline(
                x=data['crowd_count'].mean(),
                line_dash="dash",
                line_color="orange",
                annotation_text=f"Average: {data['crowd_count'].mean():.1f}"
            )
            
            fig_dist.add_vline(
                x=threshold,
                line_dash="dash",
                line_color="red",
                annotation_text=f"Threshold: {threshold}"
            )
            
            fig_dist.update_layout(
                title="Crowd Count Distribution",
                xaxis_title="Crowd Count",
                yaxis_title="Frequency",
                height=400
            )
            
            st.plotly_chart(fig_dist, use_container_width=True)
    
    # Alert analysis
    if show_alerts:
        st.header("🚨 Alert Analysis")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            alert_data = data[data['alert_triggered']]
            if len(alert_data) > 0:
                # Alert frequency over time
                alert_data['date'] = alert_data['timestamp'].dt.date
                daily_alerts = alert_data.groupby('date').size().reset_index(name='alert_count')
                
                fig_alerts = px.bar(
                    daily_alerts,
                    x='date',
                    y='alert_count',
                    title="Daily Alert Frequency",
                    color='alert_count',
                    color_continuous_scale='Reds'
                )
                
                st.plotly_chart(fig_alerts, use_container_width=True)
            else:
                st.info("No alerts in selected time range")
        
        with col2:
            if len(alert_data) > 0:
                # Alert duration analysis
                alert_durations = []
                current_alert_start = None
                
                for _, row in data.iterrows():
                    if row['alert_triggered'] and current_alert_start is None:
                        current_alert_start = row['timestamp']
                    elif not row['alert_triggered'] and current_alert_start is not None:
                        duration = (row['timestamp'] - current_alert_start).total_seconds() / 60
                        alert_durations.append(duration)
                        current_alert_start = None
                
                if alert_durations:
                    fig_duration = go.Figure()
                    fig_duration.add_trace(go.Box(
                        y=alert_durations,
                        name='Alert Duration',
                        marker_color='red'
                    ))
                    
                    fig_duration.update_layout(
                        title="Alert Duration Distribution",
                        yaxis_title="Duration (minutes)",
                        height=300
                    )
                    
                    st.plotly_chart(fig_duration, use_container_width=True)
                    
                    st.metric("Avg Alert Duration", f"{np.mean(alert_durations):.1f} min")
        
        with col3:
            if len(alert_data) > 0:
                # Alert severity analysis based on crowd count
                severity_bins = pd.cut(alert_data['crowd_count'], 
                                     bins=[threshold, threshold*1.5, threshold*2, float('inf')],
                                     labels=['Low', 'Medium', 'High'])
                severity_counts = severity_bins.value_counts()
                
                fig_severity = go.Figure(data=[go.Pie(
                    labels=severity_counts.index,
                    values=severity_counts.values,
                    hole=0.3,
                    marker_colors=['yellow', 'orange', 'red']
                )])
                
                fig_severity.update_layout(
                    title="Alert Severity Distribution",
                    height=300
                )
                
                st.plotly_chart(fig_severity, use_container_width=True)
    
    # Performance metrics
    if show_performance:
        st.header("⚡ System Performance Metrics")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # Confidence analysis
            fig_conf = go.Figure()
            
            fig_conf.add_trace(go.Scatter(
                x=data['timestamp'],
                y=data['confidence'],
                mode='lines',
                name='Confidence Score',
                line=dict(color='green', width=2)
            ))
            
            fig_conf.add_hline(
                y=data['confidence'].mean(),
                line_dash="dash",
                line_color="orange",
                annotation_text=f"Average: {data['confidence'].mean():.3f}"
            )
            
            fig_conf.update_layout(
                title="Detection Confidence Over Time",
                xaxis_title="Time",
                yaxis_title="Confidence Score",
                height=300,
                yaxis=dict(range=[0, 1])
            )
            
            st.plotly_chart(fig_conf, use_container_width=True)
        
        with col2:
            # Accuracy estimation (simulated)
            accuracy_data = 0.765 + np.random.normal(0, 0.02, len(data))
            accuracy_data = np.clip(accuracy_data, 0.7, 0.85)
            
            fig_acc = go.Figure()
            
            fig_acc.add_trace(go.Scatter(
                x=data['timestamp'],
                y=accuracy_data,
                mode='lines',
                name='Estimated Accuracy',
                line=dict(color='blue', width=2)
            ))
            
            fig_acc.update_layout(
                title="Estimated Detection Accuracy",
                xaxis_title="Time",
                yaxis_title="Accuracy",
                height=300,
                yaxis=dict(range=[0.6, 0.9])
            )
            
            st.plotly_chart(fig_acc, use_container_width=True)
        
        with col3:
            # Processing performance (simulated FPS)
            fps_data = 24 + np.random.normal(0, 3, len(data))
            fps_data = np.clip(fps_data, 15, 35)
            
            fig_fps = go.Figure()
            
            fig_fps.add_trace(go.Scatter(
                x=data['timestamp'],
                y=fps_data,
                mode='lines',
                name='Processing Speed',
                line=dict(color='purple', width=2)
            ))
            
            fig_fps.update_layout(
                title="Processing Speed (FPS)",
                xaxis_title="Time",
                yaxis_title="Frames Per Second",
                height=300
            )
            
            st.plotly_chart(fig_fps, use_container_width=True)
    
    # Data export section
    st.divider()
    st.header("📥 Data Export")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📊 Export Analysis Report"):
            report_data = {
                'Time Range': time_range,
                'Total Detections': len(data),
                'Average Crowd': data['crowd_count'].mean(),
                'Peak Crowd': data['crowd_count'].max(),
                'Total Alerts': data['alert_triggered'].sum(),
                'Alert Rate': (data['alert_triggered'].sum() / len(data)) * 100,
                'Average Confidence': data['confidence'].mean()
            }
            
            report_df = pd.DataFrame([report_data])
            csv = report_df.to_csv(index=False)
            
            st.download_button(
                label="Download Report CSV",
                data=csv,
                file_name=f"crowd_analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button("📈 Export Raw Data"):
            csv = data.to_csv(index=False)
            st.download_button(
                label="Download Raw Data CSV",
                data=csv,
                file_name=f"crowd_raw_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col3:
        if st.button("🚨 Export Alert Data"):
            alert_data = data[data['alert_triggered']]
            if len(alert_data) > 0:
                csv = alert_data.to_csv(index=False)
                st.download_button(
                    label="Download Alert Data CSV",
                    data=csv,
                    file_name=f"crowd_alerts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
            else:
                st.info("No alert data to export")

else:
    st.info("No data available for the selected time range. Start live detection to generate analytics data.")
    
    if st.button("🎥 Go to Live Detection"):
        st.switch_page("pages/1_Live_Detection.py")
