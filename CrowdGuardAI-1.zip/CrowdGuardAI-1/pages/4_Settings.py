import streamlit as st
import json
import os
from datetime import datetime
from utils.data_handler import DataHandler

st.set_page_config(
    page_title="Settings - CrowdGuard AI",
    page_icon="⚙️",
    layout="wide"
)

st.title("⚙️ System Settings")
st.markdown("**Configure CrowdGuard AI system parameters and preferences**")

# Initialize data handler
@st.cache_resource
def get_data_handler():
    return DataHandler()

data_handler = get_data_handler()

# Load current settings
@st.cache_data
def load_settings():
    default_settings = {
        "detection": {
            "model": "YOLOv8n",
            "confidence_threshold": 0.5,
            "nms_threshold": 0.4,
            "input_resolution": "640x640",
            "batch_size": 1,
            "device": "auto"
        },
        "alerts": {
            "enabled": True,
            "threshold": 50,
            "severity_levels": {"low": 40, "medium": 50, "high": 70},
            "response_time": 30,
            "auto_escalation": True
        },
        "notifications": {
            "email": {"enabled": True, "recipients": []},
            "sms": {"enabled": False, "recipients": []},
            "webhook": {"enabled": False, "url": ""},
            "audio": {"enabled": True, "volume": 80}
        },
        "data": {
            "logging_enabled": True,
            "retention_days": 30,
            "export_format": "CSV",
            "auto_backup": True,
            "backup_interval": 24
        },
        "ui": {
            "theme": "light",
            "refresh_rate": 2,
            "chart_points": 100,
            "show_confidence": True,
            "show_fps": True
        },
        "camera": {
            "source": "webcam",
            "resolution": "1280x720",
            "fps": 30,
            "rotation": 0,
            "flip": False
        }
    }
    
    # Try to load from file, otherwise use defaults
    try:
        if os.path.exists("config/settings.json"):
            with open("config/settings.json", "r") as f:
                saved_settings = json.load(f)
                # Merge with defaults to ensure all keys exist
                for category in default_settings:
                    if category in saved_settings:
                        default_settings[category].update(saved_settings[category])
    except:
        pass
    
    return default_settings

settings = load_settings()

# Function to save settings
def save_settings(new_settings):
    os.makedirs("config", exist_ok=True)
    with open("config/settings.json", "w") as f:
        json.dump(new_settings, f, indent=2)
    st.cache_data.clear()

# Sidebar - Quick Actions
with st.sidebar:
    st.header("🚀 Quick Actions")
    
    if st.button("💾 Save All Settings", type="primary"):
        save_settings(settings)
        st.success("Settings saved successfully!")
    
    if st.button("🔄 Reset to Defaults"):
        if st.session_state.get('confirm_reset'):
            # Reset and save
            default_settings = load_settings.__wrapped__()
            save_settings(default_settings)
            st.success("Settings reset to defaults!")
            st.rerun()
        else:
            st.session_state.confirm_reset = True
            st.warning("Click again to confirm reset")
    
    if st.button("📥 Export Settings"):
        settings_json = json.dumps(settings, indent=2)
        st.download_button(
            label="Download settings.json",
            data=settings_json,
            file_name=f"crowdguard_settings_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json"
        )
    
    st.divider()
    
    # Import settings
    st.subheader("📤 Import Settings")
    uploaded_file = st.file_uploader("Upload settings file", type=['json'])
    if uploaded_file is not None:
        try:
            imported_settings = json.loads(uploaded_file.read())
            save_settings(imported_settings)
            st.success("Settings imported successfully!")
            st.rerun()
        except Exception as e:
            st.error(f"Error importing settings: {e}")
    
    st.divider()
    
    # System info
    st.subheader("📊 System Info")
    st.metric("Version", "1.0.0")
    st.metric("Uptime", "24h 15m")
    st.metric("Config File", "✅ Loaded")

# Main settings tabs
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "🔍 Detection", "🚨 Alerts", "📢 Notifications", 
    "💾 Data Management", "🎨 Interface", "📹 Camera"
])

# Detection Settings
with tab1:
    st.header("🔍 Detection Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Model Settings")
        
        model_options = ["YOLOv8n", "YOLOv8s", "YOLOv8m", "YOLOv8l", "YOLOv8x"]
        settings["detection"]["model"] = st.selectbox(
            "YOLO Model",
            model_options,
            index=model_options.index(settings["detection"]["model"]),
            help="Larger models are more accurate but slower"
        )
        
        settings["detection"]["confidence_threshold"] = st.slider(
            "Confidence Threshold",
            0.1, 1.0,
            settings["detection"]["confidence_threshold"],
            0.05,
            help="Minimum confidence for person detection"
        )
        
        settings["detection"]["nms_threshold"] = st.slider(
            "NMS Threshold",
            0.1, 1.0,
            settings["detection"]["nms_threshold"],
            0.05,
            help="Non-maximum suppression threshold"
        )
        
        resolution_options = ["416x416", "640x640", "832x832", "1024x1024"]
        settings["detection"]["input_resolution"] = st.selectbox(
            "Input Resolution",
            resolution_options,
            index=resolution_options.index(settings["detection"]["input_resolution"]),
            help="Higher resolution improves accuracy but reduces speed"
        )
    
    with col2:
        st.subheader("Performance Settings")
        
        settings["detection"]["batch_size"] = st.number_input(
            "Batch Size",
            min_value=1, max_value=16,
            value=settings["detection"]["batch_size"],
            help="Number of frames processed together"
        )
        
        device_options = ["auto", "cpu", "cuda", "mps"]
        settings["detection"]["device"] = st.selectbox(
            "Processing Device",
            device_options,
            index=device_options.index(settings["detection"]["device"]),
            help="Device for model inference"
        )
        
        # Performance preview
        st.subheader("Expected Performance")
        model_performance = {
            "YOLOv8n": {"accuracy": "Good", "speed": "Very Fast", "memory": "Low"},
            "YOLOv8s": {"accuracy": "Better", "speed": "Fast", "memory": "Medium"},
            "YOLOv8m": {"accuracy": "Very Good", "speed": "Medium", "memory": "Medium"},
            "YOLOv8l": {"accuracy": "Excellent", "speed": "Slow", "memory": "High"},
            "YOLOv8x": {"accuracy": "Best", "speed": "Very Slow", "memory": "Very High"}
        }
        
        perf = model_performance[settings["detection"]["model"]]
        st.metric("Accuracy", perf["accuracy"])
        st.metric("Speed", perf["speed"])
        st.metric("Memory Usage", perf["memory"])

# Alert Settings
with tab2:
    st.header("🚨 Alert Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Basic Alert Settings")
        
        settings["alerts"]["enabled"] = st.checkbox(
            "Enable Alerts",
            value=settings["alerts"]["enabled"]
        )
        
        settings["alerts"]["threshold"] = st.number_input(
            "Primary Alert Threshold",
            min_value=1, max_value=500,
            value=settings["alerts"]["threshold"],
            help="Crowd count that triggers alerts"
        )
        
        settings["alerts"]["response_time"] = st.slider(
            "Response Time (seconds)",
            5, 300,
            settings["alerts"]["response_time"],
            5,
            help="Time before alert escalation"
        )
        
        settings["alerts"]["auto_escalation"] = st.checkbox(
            "Auto Escalation",
            value=settings["alerts"]["auto_escalation"],
            help="Automatically escalate unresolved alerts"
        )
    
    with col2:
        st.subheader("Severity Levels")
        
        settings["alerts"]["severity_levels"]["low"] = st.number_input(
            "Low Severity Threshold",
            min_value=1,
            max_value=settings["alerts"]["threshold"]-1,
            value=settings["alerts"]["severity_levels"]["low"]
        )
        
        settings["alerts"]["severity_levels"]["medium"] = st.number_input(
            "Medium Severity Threshold",
            min_value=settings["alerts"]["severity_levels"]["low"],
            max_value=200,
            value=settings["alerts"]["severity_levels"]["medium"]
        )
        
        settings["alerts"]["severity_levels"]["high"] = st.number_input(
            "High Severity Threshold",
            min_value=settings["alerts"]["severity_levels"]["medium"],
            max_value=500,
            value=settings["alerts"]["severity_levels"]["high"]
        )
    
    # Alert testing
    st.divider()
    st.subheader("🧪 Test Alerts")
    
    test_col1, test_col2, test_col3 = st.columns(3)
    
    with test_col1:
        if st.button("Test Low Alert"):
            st.warning("🟡 Low severity alert test")
    
    with test_col2:
        if st.button("Test Medium Alert"):
            st.warning("🟠 Medium severity alert test")
    
    with test_col3:
        if st.button("Test High Alert"):
            st.error("🔴 High severity alert test")

# Notification Settings
with tab3:
    st.header("📢 Notification Configuration")
    
    # Email notifications
    st.subheader("📧 Email Notifications")
    settings["notifications"]["email"]["enabled"] = st.checkbox(
        "Enable Email Notifications",
        value=settings["notifications"]["email"]["enabled"]
    )
    
    if settings["notifications"]["email"]["enabled"]:
        email_recipients = st.text_area(
            "Email Recipients (one per line)",
            value="\n".join(settings["notifications"]["email"]["recipients"]),
            help="Enter email addresses, one per line"
        )
        settings["notifications"]["email"]["recipients"] = [
            email.strip() for email in email_recipients.split("\n") if email.strip()
        ]
    
    st.divider()
    
    # SMS notifications
    st.subheader("📱 SMS Notifications")
    settings["notifications"]["sms"]["enabled"] = st.checkbox(
        "Enable SMS Notifications",
        value=settings["notifications"]["sms"]["enabled"]
    )
    
    if settings["notifications"]["sms"]["enabled"]:
        sms_recipients = st.text_area(
            "SMS Recipients (one per line)",
            value="\n".join(settings["notifications"]["sms"]["recipients"]),
            help="Enter phone numbers with country code, one per line"
        )
        settings["notifications"]["sms"]["recipients"] = [
            phone.strip() for phone in sms_recipients.split("\n") if phone.strip()
        ]
    
    st.divider()
    
    # Webhook notifications
    st.subheader("🔗 Webhook Notifications")
    settings["notifications"]["webhook"]["enabled"] = st.checkbox(
        "Enable Webhook Notifications",
        value=settings["notifications"]["webhook"]["enabled"]
    )
    
    if settings["notifications"]["webhook"]["enabled"]:
        settings["notifications"]["webhook"]["url"] = st.text_input(
            "Webhook URL",
            value=settings["notifications"]["webhook"]["url"],
            help="URL to send HTTP POST notifications"
        )
    
    st.divider()
    
    # Audio notifications
    st.subheader("🔊 Audio Notifications")
    settings["notifications"]["audio"]["enabled"] = st.checkbox(
        "Enable Audio Alerts",
        value=settings["notifications"]["audio"]["enabled"]
    )
    
    if settings["notifications"]["audio"]["enabled"]:
        settings["notifications"]["audio"]["volume"] = st.slider(
            "Audio Volume",
            0, 100,
            settings["notifications"]["audio"]["volume"],
            help="Alert sound volume (0-100%)"
        )

# Data Management Settings
with tab4:
    st.header("💾 Data Management")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Logging Settings")
        
        settings["data"]["logging_enabled"] = st.checkbox(
            "Enable Data Logging",
            value=settings["data"]["logging_enabled"]
        )
        
        settings["data"]["retention_days"] = st.number_input(
            "Data Retention (days)",
            min_value=1, max_value=365,
            value=settings["data"]["retention_days"],
            help="How long to keep detection data"
        )
        
        export_formats = ["CSV", "JSON", "Parquet"]
        settings["data"]["export_format"] = st.selectbox(
            "Export Format",
            export_formats,
            index=export_formats.index(settings["data"]["export_format"])
        )
    
    with col2:
        st.subheader("Backup Settings")
        
        settings["data"]["auto_backup"] = st.checkbox(
            "Enable Auto Backup",
            value=settings["data"]["auto_backup"]
        )
        
        if settings["data"]["auto_backup"]:
            settings["data"]["backup_interval"] = st.slider(
                "Backup Interval (hours)",
                1, 168,
                settings["data"]["backup_interval"],
                help="How often to create backups"
            )
    
    st.divider()
    
    # Data management actions
    st.subheader("📊 Data Actions")
    
    action_col1, action_col2, action_col3 = st.columns(3)
    
    with action_col1:
        if st.button("🗑️ Clear Old Data"):
            cutoff_date = datetime.now() - pd.Timedelta(days=settings["data"]["retention_days"])
            # This would implement actual data cleanup
            st.success(f"Cleared data older than {settings['data']['retention_days']} days")
    
    with action_col2:
        if st.button("💾 Create Backup"):
            backup_filename = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            st.success(f"Backup created: {backup_filename}")
    
    with action_col3:
        current_data = data_handler.get_recent_data(hours=24)
        if len(current_data) > 0:
            if st.button("📤 Export All Data"):
                csv_data = current_data.to_csv(index=False)
                st.download_button(
                    label="Download Data",
                    data=csv_data,
                    file_name=f"all_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )

# Interface Settings
with tab5:
    st.header("🎨 Interface Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Display Settings")
        
        theme_options = ["light", "dark", "auto"]
        settings["ui"]["theme"] = st.selectbox(
            "Theme",
            theme_options,
            index=theme_options.index(settings["ui"]["theme"])
        )
        
        settings["ui"]["refresh_rate"] = st.slider(
            "Refresh Rate (seconds)",
            1, 10,
            settings["ui"]["refresh_rate"],
            help="How often to update the dashboard"
        )
        
        settings["ui"]["chart_points"] = st.slider(
            "Chart Data Points",
            50, 500,
            settings["ui"]["chart_points"],
            help="Number of points to show in charts"
        )
    
    with col2:
        st.subheader("Visibility Settings")
        
        settings["ui"]["show_confidence"] = st.checkbox(
            "Show Confidence Scores",
            value=settings["ui"]["show_confidence"]
        )
        
        settings["ui"]["show_fps"] = st.checkbox(
            "Show FPS Counter",
            value=settings["ui"]["show_fps"]
        )
        
        # Preview current theme
        st.subheader("Theme Preview")
        if settings["ui"]["theme"] == "dark":
            st.markdown("🌙 Dark theme selected")
        elif settings["ui"]["theme"] == "light":
            st.markdown("☀️ Light theme selected")
        else:
            st.markdown("🔄 Auto theme (follows system)")

# Camera Settings
with tab6:
    st.header("📹 Camera Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Input Source")
        
        source_options = ["webcam", "ip_camera", "video_file", "rtsp_stream"]
        settings["camera"]["source"] = st.selectbox(
            "Camera Source",
            source_options,
            index=source_options.index(settings["camera"]["source"])
        )
        
        if settings["camera"]["source"] == "ip_camera":
            camera_url = st.text_input(
                "Camera URL",
                placeholder="http://192.168.1.100:8080/video"
            )
        elif settings["camera"]["source"] == "rtsp_stream":
            rtsp_url = st.text_input(
                "RTSP URL",
                placeholder="rtsp://username:password@ip:port/stream"
            )
        
        resolution_options = ["640x480", "1280x720", "1920x1080", "2560x1440"]
        settings["camera"]["resolution"] = st.selectbox(
            "Resolution",
            resolution_options,
            index=resolution_options.index(settings["camera"]["resolution"])
        )
    
    with col2:
        st.subheader("Camera Controls")
        
        settings["camera"]["fps"] = st.slider(
            "Frame Rate",
            1, 60,
            settings["camera"]["fps"],
            help="Frames per second for video capture"
        )
        
        settings["camera"]["rotation"] = st.selectbox(
            "Rotation",
            [0, 90, 180, 270],
            index=[0, 90, 180, 270].index(settings["camera"]["rotation"]),
            help="Rotate camera feed"
        )
        
        settings["camera"]["flip"] = st.checkbox(
            "Flip Horizontally",
            value=settings["camera"]["flip"],
            help="Mirror the camera feed"
        )
    
    st.divider()
    
    # Camera test
    st.subheader("📸 Camera Test")
    if st.button("Test Camera Connection"):
        st.info("Testing camera connection...")
        # This would implement actual camera testing
        st.success("Camera connection successful!")

# Footer with system status
st.divider()
st.header("📊 System Status")

status_col1, status_col2, status_col3, status_col4 = st.columns(4)

with status_col1:
    st.metric("Detection Model", settings["detection"]["model"])

with status_col2:
    st.metric("Alert Threshold", settings["alerts"]["threshold"])

with status_col3:
    st.metric("Data Retention", f"{settings['data']['retention_days']} days")

with status_col4:
    if settings["notifications"]["email"]["enabled"] or settings["notifications"]["sms"]["enabled"]:
        st.metric("Notifications", "🟢 Enabled")
    else:
        st.metric("Notifications", "🔴 Disabled")

# Auto-save mechanism
if st.session_state.get('settings_changed'):
    save_settings(settings)
    st.session_state.settings_changed = False
