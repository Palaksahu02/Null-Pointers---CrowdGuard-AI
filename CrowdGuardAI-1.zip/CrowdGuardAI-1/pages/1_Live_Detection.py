import streamlit as st
import cv2
import numpy as np
from PIL import Image
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
import time
from utils.detection import CrowdDetector
from utils.data_handler import DataHandler
from utils.visualization import create_heatmap
from utils.alerts import AlertManager

st.set_page_config(
    page_title="Live Detection - CrowdGuard AI",
    page_icon="🎥",
    layout="wide"
)

st.title("🎥 Live Crowd Detection")
st.markdown("**Real-time crowd monitoring with YOLOv8 detection**")

# Initialize components
@st.cache_resource
def get_detector():
    return CrowdDetector()

@st.cache_resource
def get_data_handler():
    return DataHandler()

@st.cache_resource
def get_alert_manager():
    return AlertManager()

detector = get_detector()
data_handler = get_data_handler()
alert_manager = get_alert_manager()

# Sidebar controls
with st.sidebar:
    st.header("🔧 Detection Controls")
    
    # Input source selection
    input_source = st.selectbox(
        "Input Source",
        ["Webcam", "Upload Video", "Demo Mode"]
    )
    
    # Detection parameters
    st.subheader("Detection Parameters")
    confidence_threshold = st.slider("Confidence Threshold", 0.1, 1.0, 0.5, 0.1)
    nms_threshold = st.slider("NMS Threshold", 0.1, 1.0, 0.4, 0.1)
    
    # Alert settings
    st.subheader("Alert Settings")
    crowd_threshold = st.number_input("Crowd Alert Threshold", min_value=1, max_value=200, value=50)
    enable_alerts = st.checkbox("Enable Alerts", value=True)
    
    # Display settings
    st.subheader("Display Settings")
    show_bounding_boxes = st.checkbox("Show Bounding Boxes", value=True)
    show_heatmap = st.checkbox("Show Density Heatmap", value=True)
    show_count_overlay = st.checkbox("Show Count Overlay", value=True)

# Main detection area
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("📹 Live Feed")
    
    # Create placeholder for video feed
    video_placeholder = st.empty()
    
    # Control buttons
    btn_col1, btn_col2, btn_col3 = st.columns(3)
    with btn_col1:
        start_detection = st.button("▶️ Start Detection", use_container_width=True)
    with btn_col2:
        stop_detection = st.button("⏹️ Stop Detection", use_container_width=True)
    with btn_col3:
        capture_frame = st.button("📸 Capture Frame", use_container_width=True)

with col2:
    st.subheader("📊 Real-time Metrics")
    
    # Metric placeholders
    current_count_placeholder = st.empty()
    confidence_placeholder = st.empty()
    fps_placeholder = st.empty()
    alert_status_placeholder = st.empty()
    
    st.subheader("🔥 Density Heatmap")
    heatmap_placeholder = st.empty()

# Detection state management
if 'detection_active' not in st.session_state:
    st.session_state.detection_active = False

if 'detection_data' not in st.session_state:
    st.session_state.detection_data = []

# Handle button clicks
if start_detection:
    st.session_state.detection_active = True
    st.success("Detection started!")

if stop_detection:
    st.session_state.detection_active = False
    st.info("Detection stopped!")

# Live detection loop (simulation)
if st.session_state.detection_active:
    if input_source == "Demo Mode":
        # Simulate live detection with synthetic data
        current_time = datetime.now()
        
        # Generate simulated crowd count with some randomness
        base_count = 30 + 20 * np.sin(time.time() / 10)  # Oscillating crowd
        noise = np.random.normal(0, 5)
        crowd_count = max(0, int(base_count + noise))
        
        # Simulate confidence and FPS
        confidence = min(1.0, 0.6 + np.random.random() * 0.3)
        fps = 20 + np.random.random() * 10
        
        # Update metrics
        with current_count_placeholder:
            delta_color = "normal"
            if crowd_count > crowd_threshold:
                delta_color = "inverse"
            st.metric("Current Count", crowd_count, delta=None)
        
        with confidence_placeholder:
            st.metric("Avg Confidence", f"{confidence:.2f}", delta=None)
        
        with fps_placeholder:
            st.metric("Processing Speed", f"{fps:.1f} FPS", delta=None)
        
        # Check for alerts
        alert_triggered = crowd_count > crowd_threshold and enable_alerts
        
        with alert_status_placeholder:
            if alert_triggered:
                st.error("🚨 CROWD ALERT!")
                alert_manager.trigger_alert(crowd_count, confidence, current_time)
            else:
                st.success("✅ Normal")
        
        # Log data
        data_handler.log_detection(current_time, crowd_count, confidence, alert_triggered)
        
        # Create simulated video frame
        frame = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        
        # Add crowd simulation visualization
        if show_bounding_boxes:
            # Simulate bounding boxes
            for i in range(crowd_count):
                x = np.random.randint(50, 590)
                y = np.random.randint(50, 430)
                w, h = 40, 80
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                if show_count_overlay:
                    cv2.putText(frame, f"Person {i+1}", (x, y-10), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        
        # Add count overlay
        if show_count_overlay:
            cv2.putText(frame, f"Count: {crowd_count}", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.putText(frame, f"Conf: {confidence:.2f}", (10, 70), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        # Display frame
        with video_placeholder:
            st.image(frame, channels="RGB", caption="Live Detection Feed")
        
        # Create and display heatmap
        if show_heatmap:
            heatmap_data = create_heatmap(crowd_count, frame.shape[:2])
            fig_heatmap = px.imshow(heatmap_data, color_continuous_scale='Reds')
            fig_heatmap.update_layout(
                title="Crowd Density",
                height=300,
                showlegend=False
            )
            fig_heatmap.update_xaxes(showticklabels=False)
            fig_heatmap.update_yaxes(showticklabels=False)
            
            with heatmap_placeholder:
                st.plotly_chart(fig_heatmap, use_container_width=True)
        
        # Auto-refresh every 2 seconds
        time.sleep(2)
        st.rerun()
        
    elif input_source == "Upload Video":
        uploaded_file = st.file_uploader("Choose a video file", type=['mp4', 'avi', 'mov'])
        if uploaded_file is not None:
            st.info("Video upload detection would be processed here")
            
    else:  # Webcam
        st.info("Webcam detection would be initialized here")

else:
    # Show placeholder when detection is not active
    with video_placeholder:
        placeholder_image = np.ones((480, 640, 3), dtype=np.uint8) * 128
        cv2.putText(placeholder_image, "Click 'Start Detection' to begin", 
                   (120, 240), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        st.image(placeholder_image, channels="RGB", caption="Detection Feed (Inactive)")
    
    with current_count_placeholder:
        st.metric("Current Count", 0)
    with confidence_placeholder:
        st.metric("Avg Confidence", "0.00")
    with fps_placeholder:
        st.metric("Processing Speed", "0 FPS")
    with alert_status_placeholder:
        st.info("🟡 Standby")

# Recent detection history
st.divider()
st.header("📈 Detection History")

recent_data = data_handler.get_recent_data(hours=1)
if len(recent_data) > 0:
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=recent_data['timestamp'],
        y=recent_data['crowd_count'],
        mode='lines+markers',
        name='Crowd Count',
        line=dict(color='#1f77b4', width=2)
    ))
    
    # Add threshold line
    fig.add_hline(y=crowd_threshold, line_dash="dash", line_color="red", 
                  annotation_text="Alert Threshold")
    
    fig.update_layout(
        title="Crowd Count - Last Hour",
        xaxis_title="Time",
        yaxis_title="Count",
        height=300
    )
    
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info("No detection data available. Start detection to see history.")

# Export controls
st.divider()
col1, col2, col3 = st.columns(3)

with col1:
    if st.button("📥 Export Session Data"):
        csv_data = data_handler.export_to_csv()
        st.download_button(
            label="Download CSV",
            data=csv_data,
            file_name=f"crowd_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )

with col2:
    if st.button("🔄 Clear Session Data"):
        data_handler.clear_session_data()
        st.success("Session data cleared!")

with col3:
    if st.button("📊 View Full Analytics"):
        st.switch_page("pages/2_Analytics.py")
