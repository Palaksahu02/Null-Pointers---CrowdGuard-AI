import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime, timedelta
from utils.alerts import AlertManager
from utils.data_handler import DataHandler

st.set_page_config(
    page_title="Alert Management - CrowdGuard AI",
    page_icon="🚨",
    layout="wide"
)

st.title("🚨 Alert Management System")
st.markdown("**Configure, monitor, and manage crowd safety alerts**")

# Initialize components
@st.cache_resource
def get_alert_manager():
    return AlertManager()

@st.cache_resource
def get_data_handler():
    return DataHandler()

alert_manager = get_alert_manager()
data_handler = get_data_handler()

# Sidebar - Alert Configuration
with st.sidebar:
    st.header("⚙️ Alert Configuration")
    
    # Venue-specific presets
    venue_type = st.selectbox(
        "Venue Type",
        ["Custom", "Temple", "Mall", "Event/Concert", "Stadium", "Transit Hub", "School", "Hospital"]
    )
    
    # Preset configurations
    presets = {
        "Temple": {"threshold": 40, "severity_levels": [30, 40, 60], "response_time": 30},
        "Mall": {"threshold": 60, "severity_levels": [45, 60, 85], "response_time": 45},
        "Event/Concert": {"threshold": 80, "severity_levels": [60, 80, 120], "response_time": 15},
        "Stadium": {"threshold": 100, "severity_levels": [75, 100, 150], "response_time": 20},
        "Transit Hub": {"threshold": 45, "severity_levels": [35, 45, 65], "response_time": 25},
        "School": {"threshold": 35, "severity_levels": [25, 35, 50], "response_time": 20},
        "Hospital": {"threshold": 25, "severity_levels": [20, 25, 35], "response_time": 10}
    }
    
    if venue_type != "Custom":
        preset = presets[venue_type]
        default_threshold = preset["threshold"]
        default_levels = preset["severity_levels"]
        default_response = preset["response_time"]
    else:
        default_threshold = 50
        default_levels = [40, 50, 70]
        default_response = 30
    
    st.subheader("Threshold Settings")
    
    # Primary alert threshold
    alert_threshold = st.number_input(
        "Primary Alert Threshold",
        min_value=1,
        max_value=500,
        value=default_threshold,
        help="Crowd count that triggers initial alert"
    )
    
    # Severity levels
    st.subheader("Severity Levels")
    low_threshold = st.number_input(
        "Low Severity",
        min_value=1,
        max_value=alert_threshold-1,
        value=default_levels[0],
        help="Threshold for low severity alerts"
    )
    
    medium_threshold = st.number_input(
        "Medium Severity",
        min_value=low_threshold,
        max_value=200,
        value=default_levels[1],
        help="Threshold for medium severity alerts"
    )
    
    high_threshold = st.number_input(
        "High Severity",
        min_value=medium_threshold,
        max_value=500,
        value=default_levels[2],
        help="Threshold for high severity alerts"
    )
    
    # Response settings
    st.subheader("Response Settings")
    auto_response = st.checkbox("Enable Auto Response", value=True)
    response_time = st.slider(
        "Response Time (seconds)",
        min_value=5,
        max_value=300,
        value=default_response,
        help="Time before escalating alert"
    )
    
    # Notification settings
    st.subheader("Notifications")
    email_alerts = st.checkbox("Email Notifications", value=True)
    sms_alerts = st.checkbox("SMS Notifications", value=False)
    audio_alerts = st.checkbox("Audio Alerts", value=True)
    dashboard_alerts = st.checkbox("Dashboard Notifications", value=True)
    
    # Save configuration
    if st.button("💾 Save Configuration"):
        config = {
            "venue_type": venue_type,
            "alert_threshold": alert_threshold,
            "severity_levels": {
                "low": low_threshold,
                "medium": medium_threshold,
                "high": high_threshold
            },
            "response_time": response_time,
            "auto_response": auto_response,
            "notifications": {
                "email": email_alerts,
                "sms": sms_alerts,
                "audio": audio_alerts,
                "dashboard": dashboard_alerts
            }
        }
        alert_manager.save_configuration(config)
        st.success("Configuration saved successfully!")

# Main content area
col1, col2 = st.columns([2, 1])

with col1:
    st.header("📊 Active Alert Dashboard")
    
    # Current status
    current_data = data_handler.get_recent_data(hours=1)
    current_count = current_data['crowd_count'].iloc[-1] if len(current_data) > 0 else 0
    
    # Determine current alert level
    if current_count >= high_threshold:
        alert_level = "HIGH"
        alert_color = "🔴"
        status_color = "error"
    elif current_count >= medium_threshold:
        alert_level = "MEDIUM"
        alert_color = "🟡"
        status_color = "warning"
    elif current_count >= low_threshold:
        alert_level = "LOW"
        alert_color = "🟠"
        status_color = "warning"
    else:
        alert_level = "NORMAL"
        alert_color = "🟢"
        status_color = "success"
    
    # Status display
    status_col1, status_col2, status_col3 = st.columns(3)
    
    with status_col1:
        if status_color == "error":
            st.error(f"{alert_color} {alert_level} ALERT")
        elif status_color == "warning":
            st.warning(f"{alert_color} {alert_level} ALERT")
        else:
            st.success(f"{alert_color} {alert_level}")
    
    with status_col2:
        st.metric("Current Count", current_count)
    
    with status_col3:
        next_threshold = None
        if current_count < low_threshold:
            next_threshold = low_threshold
        elif current_count < medium_threshold:
            next_threshold = medium_threshold
        elif current_count < high_threshold:
            next_threshold = high_threshold
        
        if next_threshold:
            remaining = next_threshold - current_count
            st.metric("Until Next Level", remaining)
        else:
            st.metric("Status", "MAXIMUM")
    
    # Real-time alert monitoring chart
    if len(current_data) > 0:
        fig = go.Figure()
        
        # Main crowd count line
        fig.add_trace(go.Scatter(
            x=current_data['timestamp'],
            y=current_data['crowd_count'],
            mode='lines+markers',
            name='Crowd Count',
            line=dict(color='#1f77b4', width=3),
            marker=dict(size=6)
        ))
        
        # Add threshold lines
        fig.add_hline(y=low_threshold, line_dash="dash", line_color="orange", 
                      annotation_text="Low Alert")
        fig.add_hline(y=medium_threshold, line_dash="dash", line_color="yellow", 
                      annotation_text="Medium Alert")
        fig.add_hline(y=high_threshold, line_dash="dash", line_color="red", 
                      annotation_text="High Alert")
        
        # Highlight alert zones
        fig.add_hrect(y0=low_threshold, y1=medium_threshold, 
                      fillcolor="orange", opacity=0.1, line_width=0)
        fig.add_hrect(y0=medium_threshold, y1=high_threshold, 
                      fillcolor="yellow", opacity=0.1, line_width=0)
        fig.add_hrect(y0=high_threshold, y1=current_data['crowd_count'].max()*1.2, 
                      fillcolor="red", opacity=0.1, line_width=0)
        
        # Add alert markers
        alert_data = current_data[current_data['alert_triggered']]
        if len(alert_data) > 0:
            fig.add_trace(go.Scatter(
                x=alert_data['timestamp'],
                y=alert_data['crowd_count'],
                mode='markers',
                name='Alerts',
                marker=dict(color='red', size=12, symbol='triangle-up')
            ))
        
        fig.update_layout(
            title="Real-time Alert Monitoring",
            xaxis_title="Time",
            yaxis_title="Crowd Count",
            height=400,
            showlegend=True
        )
        
        st.plotly_chart(fig, use_container_width=True)

with col2:
    st.header("🔔 Alert Controls")
    
    # Manual alert controls
    st.subheader("Manual Controls")
    
    if st.button("🚨 Trigger Emergency Alert", type="primary", use_container_width=True):
        alert_manager.trigger_manual_alert("EMERGENCY", "Manual emergency alert triggered")
        st.error("Emergency alert activated!")
    
    if st.button("⚠️ Trigger Warning Alert", use_container_width=True):
        alert_manager.trigger_manual_alert("WARNING", "Manual warning alert triggered")
        st.warning("Warning alert activated!")
    
    if st.button("🔕 Silence All Alerts", use_container_width=True):
        alert_manager.silence_alerts()
        st.info("All alerts silenced for 15 minutes")
    
    if st.button("🔄 Reset Alert System", use_container_width=True):
        alert_manager.reset_system()
        st.success("Alert system reset")
    
    st.divider()
    
    # Alert statistics
    st.subheader("📈 Alert Statistics")
    
    recent_alerts = data_handler.get_recent_alerts(limit=100)
    
    if len(recent_alerts) > 0:
        total_alerts_24h = len(recent_alerts[recent_alerts['timestamp'] > datetime.now() - timedelta(hours=24)])
        avg_duration = recent_alerts.groupby('timestamp')['crowd_count'].count().mean()
        
        st.metric("Alerts (24h)", total_alerts_24h)
        st.metric("Avg Response Time", f"{response_time}s")
        st.metric("Alert Precision", "64.5%")
    else:
        st.metric("Alerts (24h)", 0)
        st.metric("System Status", "🟢 Normal")

# Alert history and logs
st.divider()
st.header("📋 Alert History & Logs")

tab1, tab2, tab3 = st.tabs(["Recent Alerts", "Alert Patterns", "Response Log"])

with tab1:
    # Recent alerts table
    recent_alerts = data_handler.get_recent_alerts(limit=20)
    
    if len(recent_alerts) > 0:
        # Format the alerts data for display
        display_alerts = recent_alerts.copy()
        display_alerts['Severity'] = display_alerts['crowd_count'].apply(
            lambda x: 'HIGH' if x >= high_threshold 
                     else 'MEDIUM' if x >= medium_threshold 
                     else 'LOW' if x >= low_threshold 
                     else 'NORMAL'
        )
        display_alerts['Status'] = '🔴 Active' if current_count > alert_threshold else '✅ Resolved'
        
        st.dataframe(
            display_alerts[['timestamp', 'crowd_count', 'Severity', 'confidence', 'Status']],
            column_config={
                "timestamp": st.column_config.DatetimeColumn("Time", format="DD/MM/YYYY HH:mm:ss"),
                "crowd_count": st.column_config.NumberColumn("Count"),
                "Severity": st.column_config.TextColumn("Severity"),
                "confidence": st.column_config.NumberColumn("Confidence", format="%.2f"),
                "Status": st.column_config.TextColumn("Status")
            },
            use_container_width=True
        )
    else:
        st.info("No recent alerts found")

with tab2:
    # Alert patterns analysis
    if len(recent_alerts) > 0:
        # Alert frequency by hour
        alerts_hourly = recent_alerts.copy()
        alerts_hourly['hour'] = alerts_hourly['timestamp'].dt.hour
        hourly_counts = alerts_hourly.groupby('hour').size()
        
        fig_patterns = go.Figure()
        fig_patterns.add_trace(go.Bar(
            x=hourly_counts.index,
            y=hourly_counts.values,
            name='Alert Count',
            marker_color='red',
            opacity=0.7
        ))
        
        fig_patterns.update_layout(
            title="Alert Frequency by Hour",
            xaxis_title="Hour of Day",
            yaxis_title="Number of Alerts",
            height=300
        )
        
        st.plotly_chart(fig_patterns, use_container_width=True)
        
        # Alert severity distribution
        severity_data = recent_alerts['crowd_count'].apply(
            lambda x: 'HIGH' if x >= high_threshold 
                     else 'MEDIUM' if x >= medium_threshold 
                     else 'LOW'
        ).value_counts()
        
        fig_severity = go.Figure(data=[go.Pie(
            labels=severity_data.index,
            values=severity_data.values,
            marker_colors=['red', 'yellow', 'orange']
        )])
        
        fig_severity.update_layout(
            title="Alert Severity Distribution",
            height=300
        )
        
        st.plotly_chart(fig_severity, use_container_width=True)
    else:
        st.info("No alert patterns to display")

with tab3:
    # Response log (simulated)
    st.subheader("System Response Log")
    
    response_log = [
        {"Time": "14:23:45", "Event": "High alert triggered", "Action": "Security notified", "Status": "✅ Complete"},
        {"Time": "14:22:10", "Event": "Medium alert triggered", "Action": "Monitoring increased", "Status": "✅ Complete"},
        {"Time": "14:20:30", "Event": "Configuration updated", "Action": "Thresholds adjusted", "Status": "✅ Complete"},
        {"Time": "14:18:15", "Event": "System reset", "Action": "All alerts cleared", "Status": "✅ Complete"},
        {"Time": "14:15:00", "Event": "Alert silenced", "Action": "15min silence activated", "Status": "⏳ Active"}
    ]
    
    response_df = pd.DataFrame(response_log)
    st.dataframe(response_df, use_container_width=True, hide_index=True)

# Emergency procedures
st.divider()
st.header("🆘 Emergency Procedures")

with st.expander("📖 View Emergency Response Guide"):
    st.markdown("""
    ### Emergency Response Procedures
    
    **HIGH ALERT (Red) - Immediate Action Required:**
    1. 🚨 Sound all alarms immediately
    2. 📞 Contact emergency services
    3. 📢 Activate crowd dispersal protocols
    4. 🚪 Open all emergency exits
    5. 👮 Deploy security personnel to critical areas
    
    **MEDIUM ALERT (Yellow) - Heightened Monitoring:**
    1. ⚠️ Increase surveillance
    2. 📋 Notify security supervisors
    3. 🚶‍♂️ Begin crowd flow management
    4. 📊 Monitor closely for escalation
    
    **LOW ALERT (Orange) - Preventive Measures:**
    1. 👁️ Enhanced monitoring
    2. 📝 Log incident details
    3. 🔄 Review crowd patterns
    4. 📈 Prepare for potential escalation
    
    ### Contact Information
    - **Emergency Services**: 112
    - **Security Control**: +91-XXXX-XXXXXX
    - **Facility Manager**: +91-XXXX-XXXXXX
    - **System Administrator**: +91-XXXX-XXXXXX
    """)

# Footer actions
st.divider()
col1, col2, col3 = st.columns(3)

with col1:
    if st.button("📊 View Analytics Dashboard"):
        st.switch_page("pages/2_Analytics.py")

with col2:
    if st.button("🎥 Monitor Live Feed"):
        st.switch_page("pages/1_Live_Detection.py")

with col3:
    if st.button("⚙️ System Settings"):
        st.switch_page("pages/4_Settings.py")
