import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
from datetime import datetime, timedelta
import cv2

def create_heatmap(crowd_count, frame_shape, hotspots=None):
    """
    Create a crowd density heatmap
    """
    height, width = frame_shape
    
    # Create base heatmap
    heatmap = np.zeros((height//10, width//10))
    
    # Add density based on crowd count
    if crowd_count > 0:
        # Create random hotspots based on crowd count
        num_hotspots = min(5, max(1, crowd_count // 10))
        
        for _ in range(num_hotspots):
            # Random center for hotspot
            center_x = np.random.randint(5, heatmap.shape[1] - 5)
            center_y = np.random.randint(5, heatmap.shape[0] - 5)
            
            # Create Gaussian hotspot
            intensity = np.random.uniform(0.3, 1.0) * (crowd_count / 50)
            sigma = np.random.uniform(2, 5)
            
            for y in range(heatmap.shape[0]):
                for x in range(heatmap.shape[1]):
                    distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                    heatmap[y, x] += intensity * np.exp(-(distance**2) / (2 * sigma**2))
    
    # Add predefined hotspots if provided
    if hotspots:
        for hotspot in hotspots:
            center = hotspot['center']
            intensity = hotspot.get('intensity', 0.5)
            
            # Convert to heatmap coordinates
            hm_x = int(center[0] * heatmap.shape[1] / width)
            hm_y = int(center[1] * heatmap.shape[0] / height)
            
            # Add hotspot to heatmap
            sigma = 3
            for y in range(max(0, hm_y-6), min(heatmap.shape[0], hm_y+7)):
                for x in range(max(0, hm_x-6), min(heatmap.shape[1], hm_x+7)):
                    distance = np.sqrt((x - hm_x)**2 + (y - hm_y)**2)
                    heatmap[y, x] += intensity * np.exp(-(distance**2) / (2 * sigma**2))
    
    # Normalize heatmap
    heatmap = np.clip(heatmap, 0, 1)
    
    return heatmap

def create_time_series_chart(data, title="Crowd Count Over Time", show_alerts=True):
    """
    Create an interactive time series chart
    """
    fig = go.Figure()
    
    # Main crowd count line
    fig.add_trace(go.Scatter(
        x=data['timestamp'],
        y=data['crowd_count'],
        mode='lines+markers',
        name='Crowd Count',
        line=dict(color='#1f77b4', width=2),
        marker=dict(size=4),
        hovertemplate='<b>Time:</b> %{x}<br><b>Count:</b> %{y}<br><extra></extra>'
    ))
    
    # Add moving average if enough data
    if len(data) > 10:
        window = min(10, len(data) // 5)
        moving_avg = data['crowd_count'].rolling(window=window).mean()
        fig.add_trace(go.Scatter(
            x=data['timestamp'],
            y=moving_avg,
            mode='lines',
            name=f'Moving Average ({window})',
            line=dict(color='orange', width=2, dash='dash'),
            hovertemplate='<b>Time:</b> %{x}<br><b>Avg:</b> %{y:.1f}<br><extra></extra>'
        ))
    
    # Add alert markers
    if show_alerts and 'alert_triggered' in data.columns:
        alert_data = data[data['alert_triggered']]
        if len(alert_data) > 0:
            fig.add_trace(go.Scatter(
                x=alert_data['timestamp'],
                y=alert_data['crowd_count'],
                mode='markers',
                name='Alerts',
                marker=dict(color='red', size=10, symbol='triangle-up'),
                hovertemplate='<b>ALERT!</b><br><b>Time:</b> %{x}<br><b>Count:</b> %{y}<br><extra></extra>'
            ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Time",
        yaxis_title="Crowd Count",
        hovermode='x unified',
        showlegend=True
    )
    
    return fig

def create_distribution_chart(data, title="Crowd Count Distribution"):
    """
    Create a distribution histogram
    """
    fig = go.Figure()
    
    fig.add_trace(go.Histogram(
        x=data['crowd_count'],
        nbinsx=20,
        name='Distribution',
        marker=dict(color='skyblue', opacity=0.7),
        hovertemplate='<b>Count Range:</b> %{x}<br><b>Frequency:</b> %{y}<br><extra></extra>'
    ))
    
    # Add mean line
    mean_count = data['crowd_count'].mean()
    fig.add_vline(
        x=mean_count,
        line_dash="dash",
        line_color="red",
        annotation_text=f"Mean: {mean_count:.1f}"
    )
    
    fig.update_layout(
        title=title,
        xaxis_title="Crowd Count",
        yaxis_title="Frequency",
        showlegend=False
    )
    
    return fig

def create_hourly_pattern_chart(data, title="Hourly Crowd Patterns"):
    """
    Create hourly pattern analysis chart
    """
    if len(data) == 0:
        return go.Figure()
    
    # Add hour column if not present
    if 'hour' not in data.columns:
        data = data.copy()
        data['hour'] = data['timestamp'].dt.hour
    
    hourly_stats = data.groupby('hour').agg({
        'crowd_count': ['mean', 'max', 'min']
    }).round(1)
    
    hourly_stats.columns = ['mean', 'max', 'min']
    hourly_stats = hourly_stats.reset_index()
    
    fig = go.Figure()
    
    # Average line
    fig.add_trace(go.Scatter(
        x=hourly_stats['hour'],
        y=hourly_stats['mean'],
        mode='lines+markers',
        name='Average',
        line=dict(color='blue', width=3),
        marker=dict(size=6)
    ))
    
    # Max/Min area
    fig.add_trace(go.Scatter(
        x=hourly_stats['hour'],
        y=hourly_stats['max'],
        mode='lines',
        name='Max',
        line=dict(color='red', width=1),
        showlegend=False
    ))
    
    fig.add_trace(go.Scatter(
        x=hourly_stats['hour'],
        y=hourly_stats['min'],
        mode='lines',
        name='Range',
        line=dict(color='red', width=1),
        fill='tonexty',
        fillcolor='rgba(255,0,0,0.1)',
        showlegend=True
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Hour of Day",
        yaxis_title="Crowd Count",
        xaxis=dict(tickmode='linear', tick0=0, dtick=2),
        showlegend=True
    )
    
    return fig

def create_alert_analysis_chart(data, title="Alert Analysis"):
    """
    Create alert frequency and patterns chart
    """
    if len(data) == 0 or 'alert_triggered' not in data.columns:
        return go.Figure()
    
    alert_data = data[data['alert_triggered']].copy()
    
    if len(alert_data) == 0:
        fig = go.Figure()
        fig.add_annotation(
            text="No alerts in selected period",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(title=title)
        return fig
    
    # Alert frequency by hour
    alert_data['hour'] = alert_data['timestamp'].dt.hour
    hourly_alerts = alert_data.groupby('hour').size().reset_index(name='count')
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=hourly_alerts['hour'],
        y=hourly_alerts['count'],
        name='Alert Count',
        marker_color='red',
        opacity=0.7,
        hovertemplate='<b>Hour:</b> %{x}:00<br><b>Alerts:</b> %{y}<br><extra></extra>'
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Hour of Day",
        yaxis_title="Number of Alerts",
        xaxis=dict(tickmode='linear', tick0=0, dtick=1),
        showlegend=False
    )
    
    return fig

def create_confidence_chart(data, title="Detection Confidence Over Time"):
    """
    Create confidence score analysis chart
    """
    if len(data) == 0 or 'confidence' not in data.columns:
        return go.Figure()
    
    fig = go.Figure()
    
    # Confidence line
    fig.add_trace(go.Scatter(
        x=data['timestamp'],
        y=data['confidence'],
        mode='lines',
        name='Confidence',
        line=dict(color='green', width=2),
        hovertemplate='<b>Time:</b> %{x}<br><b>Confidence:</b> %{y:.3f}<br><extra></extra>'
    ))
    
    # Average confidence line
    avg_confidence = data['confidence'].mean()
    fig.add_hline(
        y=avg_confidence,
        line_dash="dash",
        line_color="orange",
        annotation_text=f"Average: {avg_confidence:.3f}"
    )
    
    fig.update_layout(
        title=title,
        xaxis_title="Time",
        yaxis_title="Confidence Score",
        yaxis=dict(range=[0, 1]),
        showlegend=False
    )
    
    return fig

def create_summary_metrics(data):
    """
    Create summary metrics for dashboard
    """
    if len(data) == 0:
        return {
            'total_detections': 0,
            'average_crowd': 0,
            'peak_crowd': 0,
            'total_alerts': 0,
            'alert_rate': 0,
            'avg_confidence': 0
        }
    
    metrics = {
        'total_detections': len(data),
        'average_crowd': data['crowd_count'].mean(),
        'peak_crowd': data['crowd_count'].max(),
        'min_crowd': data['crowd_count'].min(),
        'total_alerts': data['alert_triggered'].sum() if 'alert_triggered' in data.columns else 0,
        'alert_rate': (data['alert_triggered'].sum() / len(data)) * 100 if 'alert_triggered' in data.columns else 0,
        'avg_confidence': data['confidence'].mean() if 'confidence' in data.columns else 0,
        'std_crowd': data['crowd_count'].std(),
        'peak_time': data.loc[data['crowd_count'].idxmax(), 'timestamp'] if len(data) > 0 else None
    }
    
    return metrics

def create_correlation_analysis(data):
    """
    Create correlation analysis between different metrics
    """
    if len(data) < 10:
        return go.Figure()
    
    # Prepare data for correlation
    analysis_data = data.copy()
    analysis_data['hour'] = analysis_data['timestamp'].dt.hour
    analysis_data['day_of_week'] = analysis_data['timestamp'].dt.dayofweek
    
    # Select numeric columns for correlation
    numeric_cols = ['crowd_count', 'confidence', 'hour', 'day_of_week']
    if 'alert_triggered' in analysis_data.columns:
        analysis_data['alert_triggered_num'] = analysis_data['alert_triggered'].astype(int)
        numeric_cols.append('alert_triggered_num')
    
    correlation_matrix = analysis_data[numeric_cols].corr()
    
    fig = go.Figure(data=go.Heatmap(
        z=correlation_matrix.values,
        x=correlation_matrix.columns,
        y=correlation_matrix.columns,
        colorscale='RdBu',
        zmid=0,
        text=correlation_matrix.round(2).values,
        texttemplate="%{text}",
        textfont={"size": 12},
        hoverongaps=False
    ))
    
    fig.update_layout(
        title="Correlation Analysis",
        width=500,
        height=500
    )
    
    return fig

def create_multi_metric_dashboard(data):
    """
    Create a comprehensive multi-metric dashboard
    """
    if len(data) == 0:
        return go.Figure()
    
    # Create subplots
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Crowd Count Timeline', 'Distribution', 
                       'Hourly Patterns', 'Confidence Trends'),
        specs=[[{"secondary_y": False}, {"secondary_y": False}],
               [{"secondary_y": False}, {"secondary_y": False}]]
    )
    
    # Timeline
    fig.add_trace(
        go.Scatter(x=data['timestamp'], y=data['crowd_count'],
                  mode='lines', name='Count', line=dict(color='blue')),
        row=1, col=1
    )
    
    # Distribution
    fig.add_trace(
        go.Histogram(x=data['crowd_count'], nbinsx=15, name='Distribution',
                    marker=dict(color='skyblue')),
        row=1, col=2
    )
    
    # Hourly patterns
    if len(data) > 24:
        hourly_data = data.copy()
        hourly_data['hour'] = hourly_data['timestamp'].dt.hour
        hourly_avg = hourly_data.groupby('hour')['crowd_count'].mean()
        
        fig.add_trace(
            go.Bar(x=hourly_avg.index, y=hourly_avg.values, name='Hourly Avg',
                  marker=dict(color='orange')),
            row=2, col=1
        )
    
    # Confidence trends
    if 'confidence' in data.columns:
        fig.add_trace(
            go.Scatter(x=data['timestamp'], y=data['confidence'],
                      mode='lines', name='Confidence', line=dict(color='green')),
            row=2, col=2
        )
    
    fig.update_layout(
        height=600,
        showlegend=False,
        title_text="CrowdGuard AI Analytics Dashboard"
    )
    
    return fig

def create_real_time_gauge(current_count, threshold=50, max_count=100):
    """
    Create a real-time gauge for current crowd count
    """
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=current_count,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "Current Crowd Count"},
        delta={'reference': threshold},
        gauge={
            'axis': {'range': [None, max_count]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, threshold * 0.8], 'color': "lightgray"},
                {'range': [threshold * 0.8, threshold], 'color': "yellow"},
                {'range': [threshold, max_count], 'color': "red"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': threshold
            }
        }
    ))
    
    fig.update_layout(height=300)
    return fig

def create_risk_assessment_chart(risk_data):
    """
    Create risk assessment visualization
    """
    risk_levels = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']
    risk_colors = ['green', 'yellow', 'orange', 'red']
    
    # Count occurrences of each risk level
    if isinstance(risk_data, list):
        risk_counts = {level: risk_data.count(level) for level in risk_levels}
    else:
        # Assume it's a single risk level
        risk_counts = {level: 1 if level == risk_data else 0 for level in risk_levels}
    
    fig = go.Figure(data=[
        go.Pie(
            labels=list(risk_counts.keys()),
            values=list(risk_counts.values()),
            hole=0.3,
            marker_colors=risk_colors
        )
    ])
    
    fig.update_layout(
        title="Risk Level Distribution",
        annotations=[dict(text='Risk', x=0.5, y=0.5, font_size=20, showarrow=False)]
    )
    
    return fig
