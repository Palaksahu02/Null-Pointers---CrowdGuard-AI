import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import pandas as pd

class AlertManager:
    """
    Manages crowd safety alerts, configurations, and notifications
    """
    
    def __init__(self, config_file="config/alert_config.json"):
        self.config_file = config_file
        self.alert_history = []
        self.active_alerts = {}
        self.silence_until = None
        self.manual_alerts = []
        
        # Default configuration
        self.default_config = {
            "venue_type": "General",
            "alert_threshold": 50,
            "severity_levels": {
                "low": 40,
                "medium": 50,
                "high": 70
            },
            "response_time": 30,
            "auto_response": True,
            "notifications": {
                "email": False,
                "sms": False,
                "audio": True,
                "dashboard": True
            },
            "escalation_rules": {
                "auto_escalate": True,
                "escalation_delay": 300,  # 5 minutes
                "max_escalation_level": "CRITICAL"
            }
        }
        
        # Load configuration
        self.config = self.load_configuration()
        
        # Ensure config directory exists
        os.makedirs(os.path.dirname(config_file), exist_ok=True)
    
    def load_configuration(self) -> Dict[str, Any]:
        """
        Load alert configuration from file
        """
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    saved_config = json.load(f)
                    # Merge with defaults to ensure all keys exist
                    config = self.default_config.copy()
                    self._deep_update(config, saved_config)
                    return config
            else:
                return self.default_config.copy()
        except Exception as e:
            print(f"Error loading alert configuration: {e}")
            return self.default_config.copy()
    
    def save_configuration(self, config: Dict[str, Any]) -> bool:
        """
        Save alert configuration to file
        """
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2, default=str)
            self.config = config
            return True
        except Exception as e:
            print(f"Error saving alert configuration: {e}")
            return False
    
    def _deep_update(self, base_dict: Dict, update_dict: Dict):
        """
        Deep update dictionary
        """
        for key, value in update_dict.items():
            if isinstance(value, dict) and key in base_dict and isinstance(base_dict[key], dict):
                self._deep_update(base_dict[key], value)
            else:
                base_dict[key] = value
    
    def evaluate_alert_conditions(self, crowd_count: int, confidence: float, timestamp: datetime = None) -> Dict[str, Any]:
        """
        Evaluate if alert conditions are met
        """
        if timestamp is None:
            timestamp = datetime.now()
        
        # Check if alerts are silenced
        if self.silence_until and datetime.now() < self.silence_until:
            return {
                "should_alert": False,
                "reason": "Alerts are currently silenced",
                "silence_until": self.silence_until
            }
        
        # Get severity levels
        severity_levels = self.config["severity_levels"]
        alert_threshold = self.config["alert_threshold"]
        
        # Determine if alert should be triggered
        should_alert = crowd_count >= alert_threshold
        
        if not should_alert:
            return {
                "should_alert": False,
                "crowd_count": crowd_count,
                "threshold": alert_threshold,
                "reason": "Below alert threshold"
            }
        
        # Determine severity level
        if crowd_count >= severity_levels["high"]:
            severity = "HIGH"
            color = "🔴"
        elif crowd_count >= severity_levels["medium"]:
            severity = "MEDIUM"
            color = "🟡"
        elif crowd_count >= severity_levels["low"]:
            severity = "LOW"
            color = "🟠"
        else:
            severity = "NORMAL"
            color = "🟢"
        
        return {
            "should_alert": True,
            "severity": severity,
            "color": color,
            "crowd_count": crowd_count,
            "confidence": confidence,
            "timestamp": timestamp,
            "threshold": alert_threshold,
            "response_time": self.config["response_time"]
        }
    
    def trigger_alert(self, crowd_count: int, confidence: float, timestamp: datetime = None) -> Dict[str, Any]:
        """
        Trigger a crowd alert
        """
        if timestamp is None:
            timestamp = datetime.now()
        
        # Evaluate alert conditions
        alert_evaluation = self.evaluate_alert_conditions(crowd_count, confidence, timestamp)
        
        if not alert_evaluation["should_alert"]:
            return alert_evaluation
        
        # Create alert record
        alert_id = f"ALERT_{timestamp.strftime('%Y%m%d_%H%M%S')}_{crowd_count}"
        
        alert_record = {
            "id": alert_id,
            "timestamp": timestamp,
            "crowd_count": crowd_count,
            "confidence": confidence,
            "severity": alert_evaluation["severity"],
            "status": "ACTIVE",
            "acknowledged": False,
            "resolved": False,
            "response_time": self.config["response_time"],
            "venue_type": self.config["venue_type"],
            "notifications_sent": []
        }
        
        # Add to active alerts
        self.active_alerts[alert_id] = alert_record
        
        # Add to history
        self.alert_history.append(alert_record.copy())
        
        # Send notifications
        if self.config["notifications"]["dashboard"]:
            alert_record["notifications_sent"].append({
                "type": "dashboard",
                "timestamp": timestamp,
                "status": "sent"
            })
        
        if self.config["notifications"]["audio"]:
            alert_record["notifications_sent"].append({
                "type": "audio",
                "timestamp": timestamp,
                "status": "sent"
            })
        
        # Auto-escalation setup
        if self.config["escalation_rules"]["auto_escalate"]:
            alert_record["escalation_due"] = timestamp + timedelta(
                seconds=self.config["escalation_rules"]["escalation_delay"]
            )
        
        return {
            "success": True,
            "alert_id": alert_id,
            "alert_record": alert_record,
            "message": f"{alert_evaluation['color']} {alert_evaluation['severity']} alert triggered for crowd count {crowd_count}"
        }
    
    def trigger_manual_alert(self, severity: str, message: str, timestamp: datetime = None) -> Dict[str, Any]:
        """
        Trigger a manual alert
        """
        if timestamp is None:
            timestamp = datetime.now()
        
        alert_id = f"MANUAL_{timestamp.strftime('%Y%m%d_%H%M%S')}_{severity}"
        
        # Determine color based on severity
        color_map = {
            "LOW": "🟠",
            "MEDIUM": "🟡",
            "HIGH": "🔴",
            "EMERGENCY": "🚨",
            "WARNING": "⚠️"
        }
        
        color = color_map.get(severity, "🔴")
        
        manual_alert = {
            "id": alert_id,
            "timestamp": timestamp,
            "severity": severity,
            "message": message,
            "type": "MANUAL",
            "status": "ACTIVE",
            "acknowledged": False,
            "resolved": False,
            "triggered_by": "SYSTEM_OPERATOR"
        }
        
        # Add to manual alerts and history
        self.manual_alerts.append(manual_alert)
        self.alert_history.append(manual_alert.copy())
        
        return {
            "success": True,
            "alert_id": alert_id,
            "message": f"{color} Manual {severity} alert activated: {message}"
        }
    
    def acknowledge_alert(self, alert_id: str, acknowledged_by: str = "SYSTEM") -> bool:
        """
        Acknowledge an active alert
        """
        if alert_id in self.active_alerts:
            self.active_alerts[alert_id]["acknowledged"] = True
            self.active_alerts[alert_id]["acknowledged_at"] = datetime.now()
            self.active_alerts[alert_id]["acknowledged_by"] = acknowledged_by
            return True
        
        # Check manual alerts
        for alert in self.manual_alerts:
            if alert["id"] == alert_id and alert["status"] == "ACTIVE":
                alert["acknowledged"] = True
                alert["acknowledged_at"] = datetime.now()
                alert["acknowledged_by"] = acknowledged_by
                return True
        
        return False
    
    def resolve_alert(self, alert_id: str, resolved_by: str = "SYSTEM") -> bool:
        """
        Resolve an active alert
        """
        if alert_id in self.active_alerts:
            self.active_alerts[alert_id]["resolved"] = True
            self.active_alerts[alert_id]["resolved_at"] = datetime.now()
            self.active_alerts[alert_id]["resolved_by"] = resolved_by
            self.active_alerts[alert_id]["status"] = "RESOLVED"
            return True
        
        # Check manual alerts
        for alert in self.manual_alerts:
            if alert["id"] == alert_id and alert["status"] == "ACTIVE":
                alert["resolved"] = True
                alert["resolved_at"] = datetime.now()
                alert["resolved_by"] = resolved_by
                alert["status"] = "RESOLVED"
                return True
        
        return False
    
    def silence_alerts(self, duration_minutes: int = 15) -> datetime:
        """
        Silence all alerts for specified duration
        """
        self.silence_until = datetime.now() + timedelta(minutes=duration_minutes)
        return self.silence_until
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """
        Get all currently active alerts
        """
        active = []
        
        # System alerts
        for alert in self.active_alerts.values():
            if alert["status"] == "ACTIVE" and not alert["resolved"]:
                active.append(alert)
        
        # Manual alerts
        for alert in self.manual_alerts:
            if alert["status"] == "ACTIVE" and not alert["resolved"]:
                active.append(alert)
        
        # Sort by timestamp (most recent first)
        active.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return active
    
    def get_alert_history(self, limit: int = 50, hours: int = 168) -> List[Dict[str, Any]]:
        """
        Get alert history
        """
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        # Filter by time and limit
        recent_alerts = [
            alert for alert in self.alert_history
            if alert["timestamp"] >= cutoff_time
        ]
        
        # Sort by timestamp (most recent first)
        recent_alerts.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return recent_alerts[:limit]
    
    def get_alert_statistics(self, hours: int = 24) -> Dict[str, Any]:
        """
        Get alert statistics for specified period
        """
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        recent_alerts = [
            alert for alert in self.alert_history
            if alert["timestamp"] >= cutoff_time
        ]
        
        if not recent_alerts:
            return {
                "total_alerts": 0,
                "severity_breakdown": {},
                "average_response_time": 0,
                "resolution_rate": 0,
                "most_common_severity": "NONE"
            }
        
        # Severity breakdown
        severity_counts = {}
        for alert in recent_alerts:
            severity = alert.get("severity", "UNKNOWN")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
        
        # Resolution rate
        resolved_count = sum(1 for alert in recent_alerts if alert.get("resolved", False))
        resolution_rate = (resolved_count / len(recent_alerts)) * 100 if recent_alerts else 0
        
        # Most common severity
        most_common_severity = max(severity_counts, key=severity_counts.get) if severity_counts else "NONE"
        
        # Average response time (simulated)
        avg_response_time = sum(alert.get("response_time", 30) for alert in recent_alerts) / len(recent_alerts)
        
        return {
            "total_alerts": len(recent_alerts),
            "severity_breakdown": severity_counts,
            "average_response_time": avg_response_time,
            "resolution_rate": resolution_rate,
            "most_common_severity": most_common_severity,
            "active_count": len(self.get_active_alerts()),
            "time_period_hours": hours
        }
    
    def auto_resolve_old_alerts(self, max_age_hours: int = 2):
        """
        Automatically resolve alerts older than specified hours
        """
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        resolved_count = 0
        
        # Resolve old system alerts
        for alert_id, alert in self.active_alerts.items():
            if alert["timestamp"] < cutoff_time and not alert["resolved"]:
                self.resolve_alert(alert_id, "AUTO_RESOLVE")
                resolved_count += 1
        
        # Resolve old manual alerts
        for alert in self.manual_alerts:
            if (alert["timestamp"] < cutoff_time and 
                alert["status"] == "ACTIVE" and 
                not alert.get("resolved", False)):
                self.resolve_alert(alert["id"], "AUTO_RESOLVE")
                resolved_count += 1
        
        return resolved_count
    
    def escalate_unacknowledged_alerts(self):
        """
        Escalate alerts that haven't been acknowledged within time limit
        """
        current_time = datetime.now()
        escalated = []
        
        for alert_id, alert in self.active_alerts.items():
            if (not alert["acknowledged"] and 
                alert.get("escalation_due") and 
                current_time >= alert["escalation_due"]):
                
                # Escalate alert
                old_severity = alert["severity"]
                if old_severity == "LOW":
                    alert["severity"] = "MEDIUM"
                elif old_severity == "MEDIUM":
                    alert["severity"] = "HIGH"
                elif old_severity == "HIGH":
                    alert["severity"] = "CRITICAL"
                
                alert["escalated"] = True
                alert["escalated_at"] = current_time
                alert["previous_severity"] = old_severity
                
                # Set new escalation time if not at max level
                if alert["severity"] != "CRITICAL":
                    alert["escalation_due"] = current_time + timedelta(
                        seconds=self.config["escalation_rules"]["escalation_delay"]
                    )
                
                escalated.append({
                    "alert_id": alert_id,
                    "old_severity": old_severity,
                    "new_severity": alert["severity"]
                })
        
        return escalated
    
    def reset_system(self):
        """
        Reset the alert system (clear all alerts and configurations)
        """
        self.active_alerts.clear()
        self.manual_alerts.clear()
        self.silence_until = None
        
        # Keep history but mark system as reset
        reset_record = {
            "timestamp": datetime.now(),
            "action": "SYSTEM_RESET",
            "message": "Alert system was reset"
        }
        self.alert_history.append(reset_record)
    
    def export_alert_data(self, format: str = "json") -> str:
        """
        Export alert data in specified format
        """
        export_data = {
            "export_timestamp": datetime.now().isoformat(),
            "configuration": self.config,
            "active_alerts": list(self.active_alerts.values()),
            "manual_alerts": self.manual_alerts,
            "alert_history": self.alert_history[-100:],  # Last 100 alerts
            "statistics": self.get_alert_statistics(168)  # Last week
        }
        
        if format.lower() == "json":
            return json.dumps(export_data, indent=2, default=str)
        elif format.lower() == "csv":
            # Convert to DataFrame for CSV export
            all_alerts = self.alert_history
            if all_alerts:
                df = pd.DataFrame(all_alerts)
                return df.to_csv(index=False)
            else:
                return "No alert data available"
        else:
            raise ValueError(f"Unsupported export format: {format}")
    
    def get_current_status(self) -> Dict[str, Any]:
        """
        Get current alert system status
        """
        active_alerts = self.get_active_alerts()
        current_time = datetime.now()
        
        # Determine overall status
        if self.silence_until and current_time < self.silence_until:
            overall_status = "SILENCED"
            status_color = "🔕"
        elif any(alert.get("severity") == "CRITICAL" for alert in active_alerts):
            overall_status = "CRITICAL"
            status_color = "🚨"
        elif any(alert.get("severity") == "HIGH" for alert in active_alerts):
            overall_status = "HIGH_ALERT"
            status_color = "🔴"
        elif any(alert.get("severity") in ["MEDIUM", "LOW"] for alert in active_alerts):
            overall_status = "ALERT_ACTIVE"
            status_color = "🟡"
        else:
            overall_status = "NORMAL"
            status_color = "🟢"
        
        return {
            "overall_status": overall_status,
            "status_color": status_color,
            "active_alert_count": len(active_alerts),
            "is_silenced": self.silence_until and current_time < self.silence_until,
            "silence_until": self.silence_until,
            "last_alert": self.alert_history[-1] if self.alert_history else None,
            "system_uptime": "Active",
            "configuration_venue": self.config["venue_type"]
        }

class NotificationService:
    """
    Service for sending various types of notifications
    """
    
    def __init__(self):
        self.email_enabled = False
        self.sms_enabled = False
        self.webhook_enabled = False
        self.notification_history = []
    
    def send_email_notification(self, recipients: List[str], alert_data: Dict[str, Any]) -> bool:
        """
        Send email notification (placeholder implementation)
        """
        try:
            # In a real implementation, this would integrate with an email service
            notification = {
                "timestamp": datetime.now(),
                "type": "email",
                "recipients": recipients,
                "subject": f"CrowdGuard AI Alert - {alert_data.get('severity', 'UNKNOWN')}",
                "message": f"Alert triggered: Crowd count {alert_data.get('crowd_count', 0)}",
                "status": "sent"
            }
            
            self.notification_history.append(notification)
            return True
            
        except Exception as e:
            print(f"Error sending email notification: {e}")
            return False
    
    def send_sms_notification(self, recipients: List[str], alert_data: Dict[str, Any]) -> bool:
        """
        Send SMS notification (placeholder implementation)
        """
        try:
            # In a real implementation, this would integrate with an SMS service
            notification = {
                "timestamp": datetime.now(),
                "type": "sms",
                "recipients": recipients,
                "message": f"CrowdGuard Alert: {alert_data.get('severity', 'UNKNOWN')} - Count: {alert_data.get('crowd_count', 0)}",
                "status": "sent"
            }
            
            self.notification_history.append(notification)
            return True
            
        except Exception as e:
            print(f"Error sending SMS notification: {e}")
            return False
    
    def send_webhook_notification(self, webhook_url: str, alert_data: Dict[str, Any]) -> bool:
        """
        Send webhook notification (placeholder implementation)
        """
        try:
            # In a real implementation, this would make an HTTP POST request
            notification = {
                "timestamp": datetime.now(),
                "type": "webhook",
                "url": webhook_url,
                "payload": alert_data,
                "status": "sent"
            }
            
            self.notification_history.append(notification)
            return True
            
        except Exception as e:
            print(f"Error sending webhook notification: {e}")
            return False
    
    def get_notification_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Get notification history
        """
        return sorted(self.notification_history, key=lambda x: x["timestamp"], reverse=True)[:limit]
