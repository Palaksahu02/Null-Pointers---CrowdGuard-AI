import cv2
import numpy as np
from datetime import datetime
import time

class CrowdDetector:
    """
    YOLOv8-based crowd detection system
    Simulates real-time person detection and counting
    """
    
    def __init__(self, model_name="YOLOv8n", confidence_threshold=0.5):
        self.model_name = model_name
        self.confidence_threshold = confidence_threshold
        self.detection_count = 0
        self.total_detections = 0
        self.start_time = time.time()
        
        # Model performance characteristics
        self.model_specs = {
            "YOLOv8n": {"accuracy": 0.765, "speed": 30.0, "size": "small"},
            "YOLOv8s": {"accuracy": 0.795, "speed": 25.0, "size": "medium"},
            "YOLOv8m": {"accuracy": 0.825, "speed": 20.0, "size": "medium"},
            "YOLOv8l": {"accuracy": 0.855, "speed": 15.0, "size": "large"},
            "YOLOv8x": {"accuracy": 0.885, "speed": 10.0, "size": "large"}
        }
    
    def detect_people(self, frame):
        """
        Simulate person detection on a frame
        Returns detection results with bounding boxes and confidence scores
        """
        self.detection_count += 1
        height, width = frame.shape[:2]
        
        # Simulate detection based on model specs
        model_spec = self.model_specs.get(self.model_name, self.model_specs["YOLOv8n"])
        base_accuracy = model_spec["accuracy"]
        
        # Generate realistic crowd count with some randomness
        # Simulate varying crowd density throughout the day
        time_factor = np.sin(time.time() / 100) * 0.3 + 0.7  # 0.4 to 1.0
        base_count = int(30 * time_factor)
        noise = np.random.normal(0, 5)
        crowd_count = max(0, int(base_count + noise))
        
        # Generate simulated detections
        detections = []
        for i in range(crowd_count):
            # Random position within frame
            x = np.random.randint(50, width - 100)
            y = np.random.randint(50, height - 150)
            w = np.random.randint(40, 80)
            h = np.random.randint(80, 120)
            
            # Simulate confidence based on model and position
            position_factor = 1.0 - (abs(x - width/2) + abs(y - height/2)) / (width + height)
            confidence = base_accuracy + np.random.normal(0, 0.1) + position_factor * 0.1
            confidence = np.clip(confidence, 0.3, 0.95)
            
            if confidence >= self.confidence_threshold:
                detections.append({
                    'bbox': [x, y, w, h],
                    'confidence': confidence,
                    'class': 'person',
                    'id': i
                })
        
        self.total_detections += len(detections)
        
        return {
            'detections': detections,
            'count': len(detections),
            'frame_id': self.detection_count,
            'timestamp': datetime.now(),
            'model_info': {
                'name': self.model_name,
                'accuracy': base_accuracy,
                'fps': model_spec["speed"]
            }
        }
    
    def draw_detections(self, frame, detection_results, show_boxes=True, show_count=True):
        """
        Draw detection results on frame
        """
        output_frame = frame.copy()
        detections = detection_results['detections']
        
        if show_boxes:
            for detection in detections:
                bbox = detection['bbox']
                confidence = detection['confidence']
                x, y, w, h = bbox
                
                # Color based on confidence
                if confidence > 0.8:
                    color = (0, 255, 0)  # Green for high confidence
                elif confidence > 0.6:
                    color = (0, 255, 255)  # Yellow for medium confidence
                else:
                    color = (0, 165, 255)  # Orange for low confidence
                
                # Draw bounding box
                cv2.rectangle(output_frame, (x, y), (x + w, y + h), color, 2)
                
                # Draw confidence score
                label = f"Person {confidence:.2f}"
                label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)[0]
                cv2.rectangle(output_frame, (x, y - label_size[1] - 10), 
                             (x + label_size[0], y), color, -1)
                cv2.putText(output_frame, label, (x, y - 5), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        if show_count:
            count_text = f"Count: {detection_results['count']}"
            cv2.putText(output_frame, count_text, (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            
            model_text = f"Model: {self.model_name}"
            cv2.putText(output_frame, model_text, (10, 70), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        return output_frame
    
    def get_statistics(self):
        """
        Get detection statistics
        """
        runtime = time.time() - self.start_time
        avg_fps = self.detection_count / runtime if runtime > 0 else 0
        
        return {
            'total_frames': self.detection_count,
            'total_detections': self.total_detections,
            'runtime_seconds': runtime,
            'average_fps': avg_fps,
            'average_detections_per_frame': self.total_detections / max(1, self.detection_count),
            'model_name': self.model_name,
            'confidence_threshold': self.confidence_threshold
        }
    
    def reset_statistics(self):
        """
        Reset detection statistics
        """
        self.detection_count = 0
        self.total_detections = 0
        self.start_time = time.time()
    
    def update_config(self, model_name=None, confidence_threshold=None):
        """
        Update detector configuration
        """
        if model_name and model_name in self.model_specs:
            self.model_name = model_name
        
        if confidence_threshold is not None:
            self.confidence_threshold = max(0.1, min(1.0, confidence_threshold))
    
    def simulate_real_time_detection(self, duration_seconds=60):
        """
        Simulate real-time detection for testing
        Returns a generator of detection results
        """
        start_time = time.time()
        frame_count = 0
        
        while time.time() - start_time < duration_seconds:
            # Create a synthetic frame
            frame = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
            
            # Detect people
            results = self.detect_people(frame)
            
            # Add frame with detections
            annotated_frame = self.draw_detections(frame, results)
            
            yield {
                'frame': annotated_frame,
                'results': results,
                'frame_number': frame_count,
                'elapsed_time': time.time() - start_time
            }
            
            frame_count += 1
            
            # Simulate real-time processing delay
            model_spec = self.model_specs[self.model_name]
            expected_fps = model_spec["speed"]
            time.sleep(max(0, 1.0 / expected_fps))

class CrowdAnalyzer:
    """
    Advanced crowd analysis and pattern recognition
    """
    
    def __init__(self):
        self.detection_history = []
        self.crowd_patterns = {}
        self.risk_assessment = {
            'current_risk': 'LOW',
            'factors': [],
            'recommendations': []
        }
    
    def analyze_crowd_density(self, detection_results, frame_shape):
        """
        Analyze crowd density and distribution
        """
        height, width = frame_shape[:2]
        total_area = height * width
        
        detections = detection_results['detections']
        crowd_count = len(detections)
        
        if crowd_count == 0:
            return {
                'density': 0.0,
                'distribution': 'uniform',
                'hotspots': [],
                'risk_level': 'LOW'
            }
        
        # Calculate density
        person_area = sum([det['bbox'][2] * det['bbox'][3] for det in detections])
        density = person_area / total_area
        
        # Analyze distribution using clustering
        positions = [[det['bbox'][0] + det['bbox'][2]/2, det['bbox'][1] + det['bbox'][3]/2] 
                    for det in detections]
        
        # Simple hotspot detection (areas with high concentration)
        hotspots = self._detect_hotspots(positions, width, height)
        
        # Risk assessment
        risk_level = self._assess_risk(crowd_count, density, hotspots)
        
        return {
            'density': density,
            'crowd_count': crowd_count,
            'distribution': 'clustered' if len(hotspots) > 0 else 'uniform',
            'hotspots': hotspots,
            'risk_level': risk_level,
            'area_coverage': density * 100
        }
    
    def _detect_hotspots(self, positions, width, height, threshold_radius=100):
        """
        Detect areas with high crowd concentration
        """
        if len(positions) < 3:
            return []
        
        hotspots = []
        positions = np.array(positions)
        
        # Grid-based hotspot detection
        grid_size = 50
        for x in range(0, width, grid_size):
            for y in range(0, height, grid_size):
                center = np.array([x + grid_size/2, y + grid_size/2])
                
                # Count people within radius
                distances = np.linalg.norm(positions - center, axis=1)
                people_in_area = np.sum(distances < threshold_radius)
                
                if people_in_area > 5:  # Threshold for hotspot
                    hotspots.append({
                        'center': center.tolist(),
                        'people_count': int(people_in_area),
                        'radius': threshold_radius,
                        'intensity': people_in_area / 10.0  # Normalize intensity
                    })
        
        return sorted(hotspots, key=lambda x: x['people_count'], reverse=True)[:5]
    
    def _assess_risk(self, crowd_count, density, hotspots):
        """
        Assess crowd risk level based on multiple factors
        """
        risk_score = 0
        
        # Count-based risk
        if crowd_count > 80:
            risk_score += 3
        elif crowd_count > 50:
            risk_score += 2
        elif crowd_count > 30:
            risk_score += 1
        
        # Density-based risk
        if density > 0.3:
            risk_score += 3
        elif density > 0.2:
            risk_score += 2
        elif density > 0.1:
            risk_score += 1
        
        # Hotspot-based risk
        if len(hotspots) > 3:
            risk_score += 2
        elif len(hotspots) > 1:
            risk_score += 1
        
        # Determine risk level
        if risk_score >= 6:
            return 'CRITICAL'
        elif risk_score >= 4:
            return 'HIGH'
        elif risk_score >= 2:
            return 'MEDIUM'
        else:
            return 'LOW'
    
    def track_crowd_trends(self, detection_results):
        """
        Track crowd trends over time
        """
        timestamp = detection_results['timestamp']
        count = detection_results['count']
        
        # Add to history
        self.detection_history.append({
            'timestamp': timestamp,
            'count': count,
            'hour': timestamp.hour,
            'day_of_week': timestamp.weekday()
        })
        
        # Keep only last 1000 records
        if len(self.detection_history) > 1000:
            self.detection_history = self.detection_history[-1000:]
        
        # Analyze trends
        if len(self.detection_history) > 10:
            recent_counts = [h['count'] for h in self.detection_history[-10:]]
            trend = 'increasing' if recent_counts[-1] > np.mean(recent_counts[:-1]) else 'decreasing'
            
            # Calculate rate of change
            if len(recent_counts) > 1:
                rate_of_change = (recent_counts[-1] - recent_counts[0]) / len(recent_counts)
            else:
                rate_of_change = 0
            
            return {
                'trend': trend,
                'rate_of_change': rate_of_change,
                'current_count': count,
                'average_recent': np.mean(recent_counts),
                'volatility': np.std(recent_counts) if len(recent_counts) > 1 else 0
            }
        
        return {
            'trend': 'stable',
            'rate_of_change': 0,
            'current_count': count,
            'average_recent': count,
            'volatility': 0
        }
