import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import json

class DataHandler:
    """
    Handles data storage, retrieval, and management for CrowdGuard AI
    """
    
    def __init__(self, data_file="data/crowd_data.csv"):
        self.data_file = data_file
        self.session_data = []
        
        # Ensure data directory exists
        os.makedirs(os.path.dirname(data_file), exist_ok=True)
        
        # Initialize with sample data if file doesn't exist
        if not os.path.exists(data_file):
            self._create_sample_data()
    
    def _create_sample_data(self):
        """
        Create sample historical data for demonstration
        """
        # Generate 7 days of sample data
        end_time = datetime.now()
        start_time = end_time - timedelta(days=7)
        
        # Generate timestamps every 5 minutes
        timestamps = pd.date_range(start=start_time, end=end_time, freq='5min')
        
        sample_data = []
        for timestamp in timestamps:
            # Simulate realistic crowd patterns
            hour = timestamp.hour
            day_of_week = timestamp.weekday()
            
            # Base crowd count influenced by time of day and day of week
            if 9 <= hour <= 17:  # Business hours
                base_count = 40 + 20 * np.sin((hour - 9) * np.pi / 8)
            elif 18 <= hour <= 21:  # Evening rush
                base_count = 60 + 15 * np.sin((hour - 18) * np.pi / 3)
            else:  # Night/early morning
                base_count = 10 + 5 * np.random.random()
            
            # Weekend modifier
            if day_of_week >= 5:  # Weekend
                base_count *= 1.3
            
            # Add random noise
            noise = np.random.normal(0, 8)
            crowd_count = max(0, int(base_count + noise))
            
            # Simulate confidence (higher during day, lower at night)
            confidence = 0.6 + 0.3 * (hour / 24) + np.random.normal(0, 0.05)
            confidence = np.clip(confidence, 0.3, 0.95)
            
            # Determine if alert was triggered (threshold around 50)
            alert_triggered = crowd_count > 50 and np.random.random() > 0.3
            
            sample_data.append({
                'timestamp': timestamp,
                'crowd_count': crowd_count,
                'confidence': confidence,
                'alert_triggered': alert_triggered,
                'venue_type': 'Mall',
                'camera_id': 'CAM_001'
            })
        
        # Save to CSV
        df = pd.DataFrame(sample_data)
        df.to_csv(self.data_file, index=False)
    
    def log_detection(self, timestamp, crowd_count, confidence, alert_triggered, 
                     venue_type="General", camera_id="CAM_001"):
        """
        Log a single detection event
        """
        detection_record = {
            'timestamp': timestamp,
            'crowd_count': crowd_count,
            'confidence': confidence,
            'alert_triggered': alert_triggered,
            'venue_type': venue_type,
            'camera_id': camera_id
        }
        
        # Add to session data
        self.session_data.append(detection_record)
        
        # Append to CSV file
        try:
            # Check if file exists and has data
            if os.path.exists(self.data_file):
                # Append to existing file
                df_new = pd.DataFrame([detection_record])
                df_new.to_csv(self.data_file, mode='a', header=False, index=False)
            else:
                # Create new file with headers
                df_new = pd.DataFrame([detection_record])
                df_new.to_csv(self.data_file, index=False)
        except Exception as e:
            print(f"Error writing to data file: {e}")
    
    def get_recent_data(self, hours=24):
        """
        Get detection data from the last N hours
        """
        try:
            # Load from CSV
            df = pd.read_csv(self.data_file)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Add session data
            if self.session_data:
                session_df = pd.DataFrame(self.session_data)
                session_df['timestamp'] = pd.to_datetime(session_df['timestamp'])
                df = pd.concat([df, session_df], ignore_index=True)
            
            # Filter by time range
            cutoff_time = datetime.now() - timedelta(hours=hours)
            recent_data = df[df['timestamp'] >= cutoff_time].copy()
            
            # Sort by timestamp
            recent_data = recent_data.sort_values('timestamp').reset_index(drop=True)
            
            return recent_data
            
        except Exception as e:
            print(f"Error loading data: {e}")
            # Return session data only if file loading fails
            if self.session_data:
                df = pd.DataFrame(self.session_data)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                cutoff_time = datetime.now() - timedelta(hours=hours)
                return df[df['timestamp'] >= cutoff_time].copy()
            else:
                return pd.DataFrame(columns=['timestamp', 'crowd_count', 'confidence', 
                                           'alert_triggered', 'venue_type', 'camera_id'])
    
    def get_data_range(self, start_time, end_time):
        """
        Get detection data for a specific time range
        """
        try:
            df = pd.read_csv(self.data_file)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Add session data
            if self.session_data:
                session_df = pd.DataFrame(self.session_data)
                session_df['timestamp'] = pd.to_datetime(session_df['timestamp'])
                df = pd.concat([df, session_df], ignore_index=True)
            
            # Filter by time range
            filtered_data = df[
                (df['timestamp'] >= start_time) & 
                (df['timestamp'] <= end_time)
            ].copy()
            
            return filtered_data.sort_values('timestamp').reset_index(drop=True)
            
        except Exception as e:
            print(f"Error loading data range: {e}")
            return pd.DataFrame(columns=['timestamp', 'crowd_count', 'confidence', 
                                       'alert_triggered', 'venue_type', 'camera_id'])
    
    def get_recent_alerts(self, limit=10):
        """
        Get recent alert events
        """
        recent_data = self.get_recent_data(hours=168)  # Last week
        alerts = recent_data[recent_data['alert_triggered'] == True].copy()
        
        # Sort by timestamp descending and limit
        alerts = alerts.sort_values('timestamp', ascending=False).head(limit)
        
        return alerts.reset_index(drop=True)
    
    def get_statistics(self, hours=24):
        """
        Get statistical summary of detection data
        """
        data = self.get_recent_data(hours=hours)
        
        if len(data) == 0:
            return {
                'total_detections': 0,
                'average_crowd': 0,
                'peak_crowd': 0,
                'total_alerts': 0,
                'alert_rate': 0,
                'average_confidence': 0
            }
        
        stats = {
            'total_detections': len(data),
            'average_crowd': data['crowd_count'].mean(),
            'peak_crowd': data['crowd_count'].max(),
            'min_crowd': data['crowd_count'].min(),
            'total_alerts': data['alert_triggered'].sum(),
            'alert_rate': (data['alert_triggered'].sum() / len(data)) * 100,
            'average_confidence': data['confidence'].mean(),
            'peak_time': data.loc[data['crowd_count'].idxmax(), 'timestamp'] if len(data) > 0 else None,
            'data_points': len(data),
            'time_span_hours': hours
        }
        
        return stats
    
    def export_to_csv(self, include_session=True):
        """
        Export all data to CSV format
        """
        try:
            df = pd.read_csv(self.data_file)
            
            if include_session and self.session_data:
                session_df = pd.DataFrame(self.session_data)
                df = pd.concat([df, session_df], ignore_index=True)
            
            return df.to_csv(index=False)
            
        except Exception as e:
            print(f"Error exporting data: {e}")
            if self.session_data:
                session_df = pd.DataFrame(self.session_data)
                return session_df.to_csv(index=False)
            else:
                return ""
    
    def export_to_json(self, include_session=True):
        """
        Export all data to JSON format
        """
        try:
            df = pd.read_csv(self.data_file)
            
            if include_session and self.session_data:
                session_df = pd.DataFrame(self.session_data)
                df = pd.concat([df, session_df], ignore_index=True)
            
            # Convert timestamps to string for JSON serialization
            df['timestamp'] = df['timestamp'].astype(str)
            
            return df.to_json(orient='records', indent=2)
            
        except Exception as e:
            print(f"Error exporting to JSON: {e}")
            return "[]"
    
    def clear_session_data(self):
        """
        Clear current session data
        """
        self.session_data = []
    
    def backup_data(self, backup_path=None):
        """
        Create a backup of the data file
        """
        if backup_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"data/backup_crowd_data_{timestamp}.csv"
        
        try:
            # Ensure backup directory exists
            os.makedirs(os.path.dirname(backup_path), exist_ok=True)
            
            # Copy current data file
            if os.path.exists(self.data_file):
                import shutil
                shutil.copy2(self.data_file, backup_path)
                return backup_path
            else:
                return None
                
        except Exception as e:
            print(f"Error creating backup: {e}")
            return None
    
    def cleanup_old_data(self, retention_days=30):
        """
        Remove data older than specified days
        """
        try:
            df = pd.read_csv(self.data_file)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            cutoff_date = datetime.now() - timedelta(days=retention_days)
            cleaned_df = df[df['timestamp'] >= cutoff_date].copy()
            
            # Save cleaned data
            cleaned_df.to_csv(self.data_file, index=False)
            
            removed_count = len(df) - len(cleaned_df)
            return removed_count
            
        except Exception as e:
            print(f"Error cleaning old data: {e}")
            return 0
    
    def get_hourly_patterns(self, days=7):
        """
        Analyze hourly crowd patterns over specified days
        """
        data = self.get_recent_data(hours=days * 24)
        
        if len(data) == 0:
            return pd.DataFrame()
        
        data['hour'] = data['timestamp'].dt.hour
        hourly_stats = data.groupby('hour').agg({
            'crowd_count': ['mean', 'max', 'min', 'std', 'count'],
            'alert_triggered': 'sum'
        }).round(2)
        
        # Flatten column names
        hourly_stats.columns = ['_'.join(col).strip() for col in hourly_stats.columns]
        
        return hourly_stats.reset_index()
    
    def get_daily_patterns(self, weeks=4):
        """
        Analyze daily crowd patterns over specified weeks
        """
        data = self.get_recent_data(hours=weeks * 7 * 24)
        
        if len(data) == 0:
            return pd.DataFrame()
        
        data['day_of_week'] = data['timestamp'].dt.day_name()
        daily_stats = data.groupby('day_of_week').agg({
            'crowd_count': ['mean', 'max', 'min', 'std', 'count'],
            'alert_triggered': 'sum'
        }).round(2)
        
        # Flatten column names
        daily_stats.columns = ['_'.join(col).strip() for col in daily_stats.columns]
        
        return daily_stats.reset_index()
