# CrowdGuard AI Dashboard

## Overview

CrowdGuard AI is a real-time crowd detection and safety management system built with Streamlit and YOLOv8. The application provides comprehensive crowd monitoring capabilities including live video detection, historical analytics, alert management, and system configuration. The system is designed for venues like temples, malls, stadiums, and other public spaces where crowd safety monitoring is critical.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit multipage application with wide layout configuration
- **Navigation**: Sidebar-based navigation with four main sections:
  - Main Dashboard (app.py): Overview and summary metrics
  - Live Detection: Real-time crowd monitoring with video processing
  - Analytics: Historical data analysis and pattern recognition
  - Alert Management: Alert configuration and monitoring
  - Settings: System configuration and preferences

### Detection Engine
- **Model**: YOLOv8-based crowd detection with configurable model variants (n/s/m/l/x)
- **Input Sources**: Supports webcam, video upload, and demo mode
- **Detection Pipeline**: Real-time person detection with bounding box visualization
- **Performance**: Simulated detection with realistic accuracy metrics (76.5% base accuracy)

### Data Management
- **Storage**: CSV-based data storage for crowd detection records
- **Structure**: Time-series data with timestamps, crowd counts, venue information, and detection metadata
- **Sample Data**: Generates 7 days of realistic crowd patterns for demonstration
- **Session Management**: In-memory session data handling with periodic persistence

### Alert System
- **Configuration**: Venue-specific alert presets (Temple, Mall, Stadium, etc.)
- **Severity Levels**: Three-tier alert system (Low/Medium/High) with configurable thresholds
- **Notification Types**: Email, SMS, audio alerts, and dashboard notifications
- **Escalation**: Automatic alert escalation with configurable response times

### Visualization Components
- **Real-time Charts**: Plotly-based interactive charts and graphs
- **Heatmaps**: Crowd density visualization with Gaussian hotspot modeling
- **Analytics Dashboard**: Time-series analysis, trend detection, and correlation analysis
- **Summary Metrics**: Key performance indicators and system status monitoring

### Configuration Management
- **Settings Storage**: JSON-based configuration files
- **Model Parameters**: Adjustable confidence thresholds, NMS parameters, and input resolution
- **Alert Rules**: Customizable alert thresholds and response procedures
- **Data Retention**: Configurable data logging and retention policies

## External Dependencies

### Core Libraries
- **Streamlit**: Web application framework for dashboard interface
- **OpenCV (cv2)**: Computer vision library for video processing and frame manipulation
- **YOLOv8**: Object detection model for person detection (simulated implementation)
- **Plotly**: Interactive visualization library for charts, graphs, and heatmaps
- **Pandas**: Data manipulation and analysis for time-series crowd data
- **NumPy**: Numerical computing for detection algorithms and data processing

### Data Visualization
- **Plotly Express**: High-level plotting interface for quick visualizations
- **Plotly Graph Objects**: Low-level plotting for custom chart configurations
- **PIL (Python Imaging Library)**: Image processing and manipulation

### File System Dependencies
- **JSON**: Configuration file storage and management
- **CSV**: Historical data storage and retrieval
- **OS**: File system operations and directory management

### Potential Future Integrations
- **Email Services**: SMTP integration for alert notifications
- **SMS Services**: Third-party SMS API integration
- **Webhook Services**: External system integration for alert forwarding
- **Database Systems**: Potential migration from CSV to PostgreSQL or SQLite for scalability